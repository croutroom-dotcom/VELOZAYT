import React, { useState } from 'react';
import { Smartphone, Monitor, Apple, Music, Check, ArrowRight } from 'lucide-react';

export const GuidePage: React.FC = () => {
  const [deviceTab, setDeviceTab] = useState<'ios' | 'android' | 'pc' | 'mac'>('ios');

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Comprehensive Tutorial
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          How to Download on Any Device
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Step-by-step instructions for saving 4K videos and 320kbps MP3 audio onto your iPhone, Android, Windows, or Mac.
        </p>
      </div>

      {/* Device Selector Tabs */}
      <div className="flex items-center justify-center gap-2 p-1.5 rounded-2xl bg-neutral-900 dark:bg-neutral-900 bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-200 max-w-xl mx-auto mb-10">
        <button
          onClick={() => setDeviceTab('ios')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            deviceTab === 'ios'
              ? 'bg-[#E51B2B] text-white shadow-md shadow-[#E51B2B]/30'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Apple className="w-4 h-4" />
          iPhone & iPad
        </button>
        <button
          onClick={() => setDeviceTab('android')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            deviceTab === 'android'
              ? 'bg-[#E51B2B] text-white shadow-md shadow-[#E51B2B]/30'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Smartphone className="w-4 h-4" />
          Android
        </button>
        <button
          onClick={() => setDeviceTab('pc')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            deviceTab === 'pc'
              ? 'bg-[#E51B2B] text-white shadow-md shadow-[#E51B2B]/30'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Monitor className="w-4 h-4" />
          Windows PC
        </button>
        <button
          onClick={() => setDeviceTab('mac')}
          className={`flex-1 py-2.5 px-4 rounded-xl text-xs font-bold flex items-center justify-center gap-1.5 transition-all cursor-pointer ${
            deviceTab === 'mac'
              ? 'bg-[#E51B2B] text-white shadow-md shadow-[#E51B2B]/30'
              : 'text-neutral-400 hover:text-white'
          }`}
        >
          <Apple className="w-4 h-4" />
          Mac (macOS)
        </button>
      </div>

      {/* Guide Content per Device */}
      <div className="p-6 sm:p-8 rounded-3xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
        {deviceTab === 'ios' && (
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-white dark:text-white text-neutral-900 flex items-center gap-2">
              <Apple className="w-5 h-5 text-[#E51B2B]" />
              Downloading on iPhone & iPad (Safari)
            </h3>
            <ol className="space-y-4 text-xs sm:text-sm text-neutral-300 dark:text-neutral-300 text-neutral-700">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#E51B2B] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Copy the Video Link
                  </strong>
                  Open YouTube, TikTok, or Instagram. Tap <strong>Share</strong> &gt; <strong>Copy Link</strong>.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#E51B2B] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Analyze & Select Quality in Safari
                  </strong>
                  Open <strong>Safari</strong>, go to VELOZA YT, paste your link, and click <strong>Analyze Media</strong>. Choose your resolution (e.g. 1080p Full HD) or MP3 audio.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#E51B2B] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Confirm Safari Download Prompt
                  </strong>
                  When the popup asks <em>"Do you want to download [file]?"</em>, tap <strong>Download</strong>. The blue downward arrow in Safari's address bar indicates progress.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#E51B2B] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  4
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Move to Photos / Camera Roll (Optional)
                  </strong>
                  Tap the blue download icon &gt; tap your video file &gt; tap the <strong>Share</strong> icon (bottom left) &gt; select <strong>Save Video</strong>. It is now in your Apple Photos app!
                </div>
              </li>
            </ol>
          </div>
        )}

        {deviceTab === 'android' && (
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-white dark:text-white text-neutral-900 flex items-center gap-2">
              <Smartphone className="w-5 h-5 text-emerald-400" />
              Downloading on Android (Chrome / Samsung Internet)
            </h3>
            <ol className="space-y-4 text-xs sm:text-sm text-neutral-300 dark:text-neutral-300 text-neutral-700">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Copy the Link from Your Social App
                  </strong>
                  In YouTube, TikTok, or Instagram, tap <strong>Share</strong> &gt; <strong>Copy Link</strong>.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Paste & Analyze on VELOZA YT
                  </strong>
                  Paste the URL in VELOZA YT and select your desired format (e.g. 4K Ultra HD or 320kbps MP3).
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-emerald-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Tap Download
                  </strong>
                  Chrome will immediately stream the file. Once finished, open your notification shade or standard <strong>Files / Gallery</strong> app to watch anytime offline.
                </div>
              </li>
            </ol>
          </div>
        )}

        {deviceTab === 'pc' && (
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-white dark:text-white text-neutral-900 flex items-center gap-2">
              <Monitor className="w-5 h-5 text-[#176BCE]" />
              Downloading on Windows PC (Chrome, Edge, Firefox)
            </h3>
            <ol className="space-y-4 text-xs sm:text-sm text-neutral-300 dark:text-neutral-300 text-neutral-700">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#176BCE] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Copy URL from the Address Bar
                  </strong>
                  Highlight the video URL in your browser and press <kbd className="px-1 py-0.5 bg-neutral-800 rounded text-xs text-white">Ctrl + C</kbd>.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#176BCE] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Select 4K Ultra HD or 60FPS
                  </strong>
                  On desktop screens, choose full 4K (2160p) or 2K (1440p) to take full advantage of your monitor’s resolution.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-[#176BCE] text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Direct Save to Downloads Folder
                  </strong>
                  Files are saved automatically to your <code className="text-[#E51B2B]">C:\Users\...\Downloads</code> folder ready to open in VLC, Windows Media Player, or Premiere Pro.
                </div>
              </li>
            </ol>
          </div>
        )}

        {deviceTab === 'mac' && (
          <div className="space-y-6">
            <h3 className="text-lg font-bold text-white dark:text-white text-neutral-900 flex items-center gap-2">
              <Apple className="w-5 h-5 text-purple-400" />
              Downloading on Mac (macOS Safari & Chrome)
            </h3>
            <ol className="space-y-4 text-xs sm:text-sm text-neutral-300 dark:text-neutral-300 text-neutral-700">
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-purple-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  1
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Copy Media URL
                  </strong>
                  Copy any media link using <kbd className="px-1 py-0.5 bg-neutral-800 rounded text-xs text-white">Cmd + C</kbd>.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-purple-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  2
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Select Quick MP4 or Lossless AAC
                  </strong>
                  MP4 and M4A formats play natively in QuickTime and Apple Music without needing third-party codec packs.
                </div>
              </li>
              <li className="flex items-start gap-3">
                <span className="w-6 h-6 rounded-full bg-purple-500 text-white text-xs font-bold flex items-center justify-center shrink-0 mt-0.5">
                  3
                </span>
                <div>
                  <strong className="text-white dark:text-white text-neutral-900 block mb-0.5">
                    Access via Finder
                  </strong>
                  Click <strong>Download</strong> and access your completed file inside your Mac's <strong>Downloads</strong> folder or Finder sidebar.
                </div>
              </li>
            </ol>
          </div>
        )}
      </div>
    </div>
  );
};
