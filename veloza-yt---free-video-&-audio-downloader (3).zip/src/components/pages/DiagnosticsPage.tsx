import React, { useState, useEffect } from 'react';
import {
  Activity,
  ShieldCheck,
  CheckCircle2,
  XCircle,
  Play,
  RotateCw,
  Server,
  HardDrive,
  Cpu,
  Lock,
  AlertTriangle,
  Scale,
  FileCheck,
} from 'lucide-react';
import { DiagnosticTestResult, SystemHealth, PlatformItem } from '../../types';

export const DiagnosticsPage: React.FC = () => {
  const [health, setHealth] = useState<SystemHealth | null>(null);
  const [testResults, setTestResults] = useState<DiagnosticTestResult[]>([]);
  const [isRunningTests, setIsRunningTests] = useState<boolean>(false);
  const [platforms, setPlatforms] = useState<PlatformItem[]>([]);
  const [activeTab, setActiveTab] = useState<'tests' | 'health' | 'transparency'>('tests');

  // Load health and platforms on mount
  useEffect(() => {
    fetchHealth();
    fetchPlatforms();
  }, []);

  const fetchHealth = async () => {
    try {
      const res = await fetch('/api/health');
      if (res.ok) {
        const data = await res.json();
        setHealth(data);
      }
    } catch (e) {
      console.warn('Failed to fetch health metrics:', e);
    }
  };

  const fetchPlatforms = async () => {
    try {
      const res = await fetch('/api/platforms');
      if (res.ok) {
        const data = await res.json();
        if (data && data.platforms) {
          setPlatforms(data.platforms);
        }
      }
    } catch (e) {
      console.warn('Failed to fetch platform matrix:', e);
    }
  };

  const handleRunDiagnostics = async () => {
    setIsRunningTests(true);
    setTestResults([]);
    try {
      const res = await fetch('/api/diagnostics/run-tests');
      if (res.ok) {
        const data = await res.json();
        setTestResults(data.results || []);
      }
    } catch (err: any) {
      console.error('Error running diagnostic tests:', err);
    } finally {
      setIsRunningTests(false);
      fetchHealth();
    }
  };

  const formatUptime = (sec: number) => {
    const mins = Math.floor(sec / 60);
    const hours = Math.floor(mins / 60);
    if (hours > 0) return `${hours}h ${mins % 60}m`;
    return `${mins}m ${sec % 60}s`;
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#7C5CFF] mb-2 block">
          Quality Assurance & Production Audit
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          System Diagnostics & Transparency Report
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Real-time security invariants, automated endpoint tests, storage verification, and honest platform compatibility disclosures.
        </p>

        {/* Tab Switcher */}
        <div className="flex items-center justify-center gap-2 p-1.5 rounded-2xl bg-neutral-900 dark:bg-neutral-900 bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-200 max-w-md mx-auto mt-8">
          <button
            onClick={() => setActiveTab('tests')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'tests'
                ? 'bg-[#7C5CFF] text-white shadow-md shadow-[#7C5CFF]/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Automated Tests
          </button>
          <button
            onClick={() => setActiveTab('health')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'health'
                ? 'bg-[#7C5CFF] text-white shadow-md shadow-[#7C5CFF]/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Server Health
          </button>
          <button
            onClick={() => setActiveTab('transparency')}
            className={`flex-1 py-2 px-3 rounded-xl text-xs font-bold transition-all cursor-pointer ${
              activeTab === 'transparency'
                ? 'bg-[#7C5CFF] text-white shadow-md shadow-[#7C5CFF]/30'
                : 'text-neutral-400 hover:text-white'
            }`}
          >
            Honest Reporting
          </button>
        </div>
      </div>

      {/* 1. Automated Tests Tab */}
      {activeTab === 'tests' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-300 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div>
              <h3 className="text-base font-bold text-white dark:text-white text-neutral-900">
                Automated Security & Stream Integrity Suite
              </h3>
              <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 mt-1">
                Executes live server assertions against SSRF filters, loopback blocks, stream integrity, and storage purge.
              </p>
            </div>

            <button
              onClick={handleRunDiagnostics}
              disabled={isRunningTests}
              className="px-5 py-2.5 bg-[#7C5CFF] hover:bg-[#c91524] text-white text-xs font-bold rounded-xl shadow-md transition-all flex items-center gap-2 cursor-pointer disabled:opacity-60 whitespace-nowrap active:scale-95"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isRunningTests ? 'animate-spin' : ''}`} />
              {isRunningTests ? 'Running Automated Tests...' : 'Run Diagnostic Suite'}
            </button>
          </div>

          {/* Test Results Output */}
          <div className="space-y-3">
            {testResults.length === 0 ? (
              <div className="p-12 text-center rounded-2xl border border-neutral-800 bg-[#0e1017] text-neutral-400 text-xs">
                <FileCheck className="w-8 h-8 mx-auto mb-2 text-neutral-600" />
                Click <strong>"Run Diagnostic Suite"</strong> to execute real live automated assertions against the backend server.
              </div>
            ) : (
              testResults.map((t) => (
                <div
                  key={t.id}
                  className="p-4 rounded-xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200 flex items-start justify-between gap-3"
                >
                  <div className="flex items-start gap-3">
                    {t.passed ? (
                      <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                    ) : (
                      <XCircle className="w-5 h-5 text-red-400 shrink-0 mt-0.5" />
                    )}

                    <div>
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs sm:text-sm text-white dark:text-white text-neutral-900">
                          {t.name}
                        </span>
                        <span className="text-[10px] px-1.5 py-0.2 rounded bg-neutral-800 dark:bg-neutral-800 bg-neutral-200 text-neutral-300 dark:text-neutral-300 text-neutral-700">
                          {t.category}
                        </span>
                      </div>
                      <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 mt-1 font-mono">
                        {t.details}
                      </p>
                    </div>
                  </div>

                  <span className="text-[11px] font-mono text-neutral-500 shrink-0">
                    {t.durationMs}ms
                  </span>
                </div>
              ))
            )}
          </div>
        </div>
      )}

      {/* 2. Server Health Tab */}
      {activeTab === 'health' && health && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <div className="p-5 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
              <div className="flex items-center justify-between text-neutral-400 mb-2">
                <span className="text-xs font-semibold">Service Status</span>
                <Server className="w-4 h-4 text-emerald-400" />
              </div>
              <span className="text-xl font-extrabold text-emerald-400 uppercase">{health.status}</span>
              <span className="text-[10px] text-neutral-500 block mt-1">Uptime: {formatUptime(health.uptimeSeconds)}</span>
            </div>

            <div className="p-5 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
              <div className="flex items-center justify-between text-neutral-400 mb-2">
                <span className="text-xs font-semibold">Process RAM</span>
                <Cpu className="w-4 h-4 text-[#176BCE]" />
              </div>
              <span className="text-xl font-extrabold text-white dark:text-white text-neutral-900">
                {health.memory.rssMb} MB
              </span>
              <span className="text-[10px] text-neutral-500 block mt-1">
                Heap: {health.memory.heapUsedMb} MB / {health.memory.heapTotalMb} MB
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
              <div className="flex items-center justify-between text-neutral-400 mb-2">
                <span className="text-xs font-semibold">Temp Storage</span>
                <HardDrive className="w-4 h-4 text-amber-400" />
              </div>
              <span className="text-xl font-extrabold text-white dark:text-white text-neutral-900">
                {health.tempStorageUsageMb} MB
              </span>
              <span className="text-[10px] text-neutral-500 block mt-1">
                Limit: {health.maxStorageLimitMb} MB (TTL: 10m)
              </span>
            </div>

            <div className="p-5 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
              <div className="flex items-center justify-between text-neutral-400 mb-2">
                <span className="text-xs font-semibold">Rate Limit Shield</span>
                <ShieldCheck className="w-4 h-4 text-[#7C5CFF]" />
              </div>
              <span className="text-xl font-extrabold text-white dark:text-white text-neutral-900">
                {health.rateLimitHits} Hits
              </span>
              <span className="text-[10px] text-neutral-500 block mt-1">Active Jobs: {health.activeJobsCount}</span>
            </div>
          </div>

          <div className="p-6 rounded-2xl bg-[#0f1118] border border-neutral-800 text-xs text-neutral-300 leading-relaxed space-y-3">
            <h4 className="font-bold text-white text-sm">Security & Storage Governance</h4>
            <p>
              • <strong>Maximum File Size Limit:</strong> 500 MB per single media extraction to prevent memory exhaustion and bandwidth flooding.
            </p>
            <p>
              • <strong>Cryptographic Access Tokens:</strong> Every background processing job generates an unpredictable 32-character hexadecimal token. Only requests presenting the matching token can download the prepared file.
            </p>
            <p>
              • <strong>Automatic TTL Purge Worker:</strong> An asynchronous timer runs every 60 seconds. Any temporary job buffers exceeding 10 minutes are completely deleted from system memory.
            </p>
          </div>
        </div>
      )}

      {/* 3. Honest Feature Reporting Tab */}
      {activeTab === 'transparency' && (
        <div className="space-y-6">
          <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2 flex items-center gap-2">
              <Scale className="w-4 h-4 text-[#7C5CFF]" />
              Honest Platform Compatibility Disclosure
            </h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed mb-6">
              We never simulate fake successful downloads or claim compatibility with platforms where legal restrictions or hardware DRM prohibit extraction.
            </p>

            <div className="space-y-4">
              {platforms.map((p) => {
                const isDrm = p.category === 'unsupported_drm';
                const isRestricted = p.category === 'restricted';
                const isSupported = p.category === 'supported';

                return (
                  <div
                    key={p.id}
                    className={`p-4 rounded-xl border ${
                      isDrm
                        ? 'bg-red-950/20 border-red-800/40'
                        : isRestricted
                        ? 'bg-amber-950/20 border-amber-800/40'
                        : 'bg-neutral-900/60 dark:bg-neutral-900/60 bg-neutral-50 border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200'
                    }`}
                  >
                    <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 mb-2">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white dark:text-white text-neutral-900">
                          {p.name}
                        </span>
                        <span
                          className={`text-[10px] px-2 py-0.5 rounded font-bold ${
                            isDrm
                              ? 'bg-red-500/20 text-red-400'
                              : isRestricted
                              ? 'bg-amber-500/20 text-amber-400'
                              : 'bg-emerald-500/20 text-emerald-400'
                          }`}
                        >
                          {p.status}
                        </span>
                      </div>

                      <span className="text-xs font-semibold text-neutral-400">{p.badge}</span>
                    </div>

                    <p className="text-xs text-neutral-300 dark:text-neutral-300 text-neutral-700 mb-2">
                      {p.description}
                    </p>

                    {p.legalReason && (
                      <div className="text-[11px] text-red-300 flex items-start gap-1.5 mt-2">
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0 mt-0.5 text-red-400" />
                        <span>
                          <strong>Statutory Legal Constraint:</strong> {p.legalReason}
                        </span>
                      </div>
                    )}

                    {p.authorizedAlternative && (
                      <div className="text-[11px] text-neutral-400 flex items-start gap-1.5 mt-1">
                        <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5 text-emerald-400" />
                        <span>
                          <strong>Authorized Alternative:</strong> {p.authorizedAlternative}
                        </span>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Infrastructure & Bandwidth Cost Report */}
          <div className="p-6 rounded-2xl bg-[#0f1118] border border-neutral-800 text-xs text-neutral-300 leading-relaxed space-y-3">
            <h4 className="font-bold text-white text-sm">Production Infrastructure & Cost Modeling</h4>
            <p>
              • <strong>Bandwidth Estimation:</strong> Serving 100,000 monthly downloads at an average of 45 MB per 1080p stream generates ~4.5 TB of egress. Direct streaming pipes eliminate large intermediary disk caching.
            </p>
            <p>
              • <strong>FFmpeg Cloud Workers:</strong> For high-volume 4K DASH video/audio merging, dedicated worker pools (using stateless autoscaling containers on Cloud Run or Kubernetes) are recommended.
            </p>
            <p>
              • <strong>Zero Third-Party Scraping Vulnerabilities:</strong> Uses native oEmbed endpoints, standard HTTP range headers, and SSRF allowlisting without fragile headless browser scraping.
            </p>
          </div>
        </div>
      )}
    </div>
  );
};
