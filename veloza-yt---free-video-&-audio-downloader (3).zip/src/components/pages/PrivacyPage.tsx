import React from 'react';
import { ShieldCheck, Lock, EyeOff, Trash2, Server } from 'lucide-react';

export const PrivacyPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Trust & Confidentiality
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Privacy Policy
        </h1>
        <p className="text-sm text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Effective Date: October 2026. Zero personal tracking. No database logs. Full transparency.
        </p>
      </div>

      <div className="space-y-8 text-neutral-300 dark:text-neutral-300 text-neutral-700 text-xs sm:text-sm leading-relaxed">
        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-3 flex items-center gap-2">
            <EyeOff className="w-4 h-4 text-[#E51B2B]" />
            1. No User Profile or Identity Tracking
          </h2>
          <p>
            VELOZA YT operates as a stateless utility. We do not require users to register accounts, provide credit cards, or submit personally identifiable information (PII) to access our standard media tools.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-3 flex items-center gap-2">
            <Trash2 className="w-4 h-4 text-[#176BCE]" />
            2. Ephemeral Processing & Automatic File Deletion
          </h2>
          <p>
            When media is analyzed or converted through our servers, data is streamed directly to your browser memory or held in temporary encrypted staging buffers. These buffers are set with strict automatic TTL (Time-To-Live) expiration and are purged immediately upon download completion.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-3 flex items-center gap-2">
            <Server className="w-4 h-4 text-emerald-400" />
            3. Server Logs & IP Masking
          </h2>
          <p>
            Our web servers maintain standard ephemeral operational logs strictly for load balancing, DDoS mitigation, and system health. IP addresses in access records are pseudonymized, never stored in plaintext, and never shared or sold to advertising networks.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-3 flex items-center gap-2">
            <Lock className="w-4 h-4 text-purple-400" />
            4. Local Storage Usage
          </h2>
          <p>
            Your "Recent Downloads" history and theme selection (Light vs. Dark mode) are stored strictly on your local browser using client-side localStorage. This information never leaves your device and can be cleared at any time via the "Clear History" button.
          </p>
        </div>
      </div>
    </div>
  );
};
