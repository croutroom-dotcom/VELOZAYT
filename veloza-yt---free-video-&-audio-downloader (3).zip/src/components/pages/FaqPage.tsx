import React, { useState } from 'react';
import { ChevronDown, Search, HelpCircle } from 'lucide-react';

interface FaqItem {
  q: string;
  a: string;
  category: string;
}

export const FaqPage: React.FC = () => {
  const [search, setSearch] = useState('');
  const [openIdx, setOpenIdx] = useState<number | null>(0);

  const faqs: FaqItem[] = [
    {
      q: 'Is VELOZA YT completely free to use?',
      a: 'Yes. VELOZA YT is 100% free with no mandatory account registration, no credit card requirements, and no artificial daily download quotas. Our sustainable model operates on efficient, modern infrastructure.',
      category: 'General',
    },
    {
      q: 'Can I download videos in 4K Ultra HD (2160p) and 60FPS?',
      a: 'Absolutely. When the original content was uploaded in 4K or 2K Quad HD, VELOZA YT identifies the highest available resolution stream and presents it in the format picker with estimated file size.',
      category: 'Video Quality',
    },
    {
      q: 'How does high-quality audio extraction work?',
      a: 'When you select an audio option (like MP3 320kbps or M4A 256kbps), VELOZA YT demuxes the pristine audio track from the media source, applies high-precision 48kHz resampling without dynamic compression, and delivers a clean MP3 file.',
      category: 'Audio',
    },
    {
      q: 'Where do downloaded videos and audio get saved on my iPhone or Android?',
      a: 'On iOS (iPhone/iPad), files downloaded through Safari are saved directly in your "Files" app under "Downloads", where they can be shared to Camera Roll. On Android, files are stored in your device\'s standard "Downloads" folder and appear in your Gallery app.',
      category: 'Mobile Devices',
    },
    {
      q: 'Can I download TikTok videos without the bouncing watermark?',
      a: 'Yes. Our TikTok parser retrieves the clean direct source feed, saving vertical 9:16 video clips without the watermark overlay.',
      category: 'Platforms',
    },
    {
      q: 'Is it legal to download public videos for offline viewing?',
      a: 'Downloading public media for personal offline archival, educational use, and fair use is generally permissible in many jurisdictions, provided you do not re-upload, monetize, or redistribute copyrighted material without permission. Always respect creators’ rights.',
      category: 'Legal & Fair Use',
    },
    {
      q: 'Why does an error appear when I enter certain links?',
      a: 'Media downloads may fail if the video is set to "Private", requires age-verification sign-in, or is protected by DRM (Digital Rights Management like Widevine or FairPlay). VELOZA YT does not bypass DRM or private security controls.',
      category: 'Troubleshooting',
    },
    {
      q: 'What is the background Download Queue feature?',
      a: 'The Download Queue allows you to process larger media files in the background. It displays live transfer speeds (in MB/s), an estimated time to completion (ETA), and a direct save button once ready.',
      category: 'Features',
    },
  ];

  const filtered = faqs.filter(
    (item) =>
      item.q.toLowerCase().includes(search.toLowerCase()) ||
      item.a.toLowerCase().includes(search.toLowerCase()) ||
      item.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      {/* Title */}
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Frequently Asked Questions
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Everything You Need to Know
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Quick answers to common questions about resolutions, audio bitrates, mobile saving, and security.
        </p>

        {/* Search Input */}
        <div className="relative mt-8 max-w-md mx-auto">
          <Search className="w-4 h-4 absolute left-3.5 top-3.5 text-neutral-500" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search questions or keywords..."
            className="w-full pl-10 pr-4 py-2.5 rounded-xl bg-[#11131A] dark:bg-[#11131A] bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-300 text-sm text-white dark:text-white text-neutral-900 focus:outline-none focus:border-[#E51B2B]"
          />
        </div>
      </div>

      {/* Accordion */}
      <div className="space-y-3">
        {filtered.length === 0 ? (
          <div className="text-center py-12 text-neutral-500 text-sm">
            No questions matching "{search}". Try searching "audio", "4K", or "mobile".
          </div>
        ) : (
          filtered.map((faq, idx) => {
            const isOpen = openIdx === idx;
            return (
              <div
                key={idx}
                className="rounded-xl border border-neutral-800 dark:border-neutral-800 border-neutral-200 bg-[#11131A] dark:bg-[#11131A] bg-white overflow-hidden transition-all"
              >
                <button
                  type="button"
                  onClick={() => setOpenIdx(isOpen ? null : idx)}
                  className="w-full text-left px-5 py-4 flex items-center justify-between gap-4 cursor-pointer"
                >
                  <span className="font-bold text-sm sm:text-base text-white dark:text-white text-neutral-900">
                    {faq.q}
                  </span>
                  <div
                    className={`w-6 h-6 rounded-full bg-neutral-800 dark:bg-neutral-800 bg-neutral-100 flex items-center justify-center shrink-0 transition-transform ${
                      isOpen ? 'rotate-180 text-[#E51B2B]' : 'text-neutral-400'
                    }`}
                  >
                    <ChevronDown className="w-4 h-4" />
                  </div>
                </button>

                {isOpen && (
                  <div className="px-5 pb-5 text-xs sm:text-sm text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed border-t border-neutral-800/60 dark:border-neutral-800/60 border-neutral-100 pt-3">
                    <p>{faq.a}</p>
                    <span className="inline-block mt-2 text-[10px] uppercase font-semibold text-neutral-500">
                      Category: {faq.category}
                    </span>
                  </div>
                )}
              </div>
            );
          })
        )}
      </div>
    </div>
  );
};
