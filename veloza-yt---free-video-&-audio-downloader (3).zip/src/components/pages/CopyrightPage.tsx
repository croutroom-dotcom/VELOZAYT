import React from 'react';
import { Copyright, Mail, ShieldCheck, AlertOctagon } from 'lucide-react';

export const CopyrightPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Intellectual Property
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Copyright & DMCA Policy
        </h1>
        <p className="text-sm text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          VELOZA YT respects the legitimate intellectual property rights of artists, publishers, and content creators.
        </p>
      </div>

      <div className="space-y-6 text-neutral-300 dark:text-neutral-300 text-neutral-700 text-xs sm:text-sm leading-relaxed">
        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2 flex items-center gap-2">
            <Copyright className="w-4 h-4 text-[#E51B2B]" />
            Digital Millennium Copyright Act (DMCA) Notice
          </h2>
          <p>
            VELOZA YT does not host, stream, or retain copyrighted video or audio archives on its servers. We function strictly as an automated transport conduit and format converter for publicly accessible streams. If you are a copyright owner or an authorized agent and believe that content accessible via our platform infringes your copyright, you may submit a formal notification.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2 flex items-center gap-2">
            <AlertOctagon className="w-4 h-4 text-amber-400" />
            Takedown Notice Requirements
          </h2>
          <p className="mb-2">
            To ensure swift action, your written notification must include the following statutory requirements:
          </p>
          <ul className="list-disc pl-5 space-y-1 text-neutral-400 dark:text-neutral-400 text-neutral-600">
            <li>Physical or electronic signature of the copyright owner or person authorized to act on their behalf.</li>
            <li>Identification of the copyrighted work claimed to have been infringed.</li>
            <li>The specific URL(s) and timestamp of the media on the originating platform.</li>
            <li>Your contact details: legal name, company/organization, mailing address, telephone number, and official email.</li>
            <li>A statement that you have a good-faith belief that the disputed use is not authorized by the copyright owner, its agent, or the law.</li>
            <li>A statement under penalty of perjury that the information in your notice is accurate.</li>
          </ul>
        </div>

        <div className="p-6 rounded-2xl bg-[#0f1118] border border-neutral-800 flex items-center justify-between flex-wrap gap-4">
          <div>
            <span className="text-white font-bold block mb-1">Designated DMCA Agent:</span>
            <span className="text-neutral-400 font-mono">dmca-legal@veloza-yt.io</span>
          </div>
          <div className="text-xs text-neutral-400">
            Standard processing turnaround: within 12–24 business hours.
          </div>
        </div>
      </div>
    </div>
  );
};
