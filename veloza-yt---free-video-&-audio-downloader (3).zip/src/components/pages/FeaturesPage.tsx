import React from 'react';
import {
  Film,
  Music2,
  Zap,
  ShieldCheck,
  Smartphone,
  Layers,
  Activity,
  Cpu,
  Lock,
  Compass,
} from 'lucide-react';

export const FeaturesPage: React.FC = () => {
  const featureList = [
    {
      icon: Film,
      title: '4K Ultra HD & 2K Processing',
      description:
        'Full support for 3840x2160 (2160p) and 2560x1440 (1440p) resolutions at up to 60 FPS using AV1 and H.264 high-profile encoding.',
      color: '#E51B2B',
    },
    {
      icon: Music2,
      title: '320 kbps Studio Audio Extraction',
      description:
        'Converts video sound into broadcast-grade 320kbps and 256kbps MP3 or AAC M4A with 48kHz sampling and complete ID3 metadata.',
      color: '#176BCE',
    },
    {
      icon: Activity,
      title: 'Live Job Queue & Speed Monitoring',
      description:
        'Real-time progress bars, connection throughput meters (MB/s), remaining ETA calculations, and background batch queues.',
      color: '#10B981',
    },
    {
      icon: Cpu,
      title: 'FFmpeg Authorized Audio/Video Merging',
      description:
        'Intelligently merges adaptive DASH video streams with separate high-bitrate audio streams into a unified, playable MP4 file.',
      color: '#F59E0B',
    },
    {
      icon: Smartphone,
      title: 'Mobile-Optimized & Cross-Platform',
      description:
        'Fluidly compatible across iOS Safari, Android Chrome, Windows, macOS, Linux, and smart television browsers.',
      color: '#8B5CF6',
    },
    {
      icon: Lock,
      title: 'SSRF Shield & Zero-Log Architecture',
      description:
        'Deep server-side URL validation, private intranet filtering, and ephemeral file storage that automatically purges completed media.',
      color: '#06B6D4',
    },
  ];

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Cutting-Edge Media Engine
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Engineered for Media Professionals & Everyday Users
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Explore the technical architecture and features that make VELOZA YT the most reliable video and audio utility on the web.
        </p>
      </div>

      {/* Feature Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mb-16">
        {featureList.map((feat, idx) => {
          const Icon = feat.icon;
          return (
            <div
              key={idx}
              className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200 hover:border-neutral-700 transition-all"
            >
              <div
                className="w-10 h-10 rounded-xl flex items-center justify-center mb-4 text-white"
                style={{ backgroundColor: feat.color }}
              >
                <Icon className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
                {feat.title}
              </h3>
              <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
                {feat.description}
              </p>
            </div>
          );
        })}
      </div>

      {/* Deep-Dive Technical Specs */}
      <div className="p-8 rounded-2xl bg-[#0f1118] border border-neutral-800">
        <h2 className="text-xl font-bold text-white mb-6">Technical Architecture Summary</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 text-xs text-neutral-300">
          <div className="space-y-2">
            <span className="font-bold text-[#E51B2B] uppercase tracking-wider block">Video Codecs</span>
            <p className="text-neutral-400">
              H.264 (AVC) Baseline/Main/High profile for universal compatibility; AV1 and VP9 for next-generation 4K compression and color fidelity.
            </p>
          </div>
          <div className="space-y-2">
            <span className="font-bold text-[#176BCE] uppercase tracking-wider block">Audio Codecs</span>
            <p className="text-neutral-400">
              MPEG-1 Audio Layer III (MP3) at up to 320 kbps constant bitrate; Advanced Audio Coding (AAC) M4A at 256 kbps; Opus and Vorbis preservation where supported.
            </p>
          </div>
          <div className="space-y-2">
            <span className="font-bold text-emerald-400 uppercase tracking-wider block">Transport Protocol</span>
            <p className="text-neutral-400">
              Direct HTTP/2 and HTTP/1.1 chunked streaming with Content-Disposition headers for seamless client-side save triggers without memory leaks.
            </p>
          </div>
          <div className="space-y-2">
            <span className="font-bold text-amber-400 uppercase tracking-wider block">Security Invariants</span>
            <p className="text-neutral-400">
              Strict hostname validation against RFC 1918 private IPv4 subnets, link-local addresses, and cloud provider instance metadata endpoints.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
