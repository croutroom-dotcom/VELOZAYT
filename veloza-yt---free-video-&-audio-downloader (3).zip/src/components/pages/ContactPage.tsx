import React, { useState } from 'react';
import { Mail, MessageSquare, Send, CheckCircle2, AlertCircle, Clock, ShieldCheck } from 'lucide-react';

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [category, setCategory] = useState('technical');
  const [subject, setSubject] = useState('');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [responseInfo, setResponseInfo] = useState<{ ticketId: string; message: string } | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    if (!name.trim() || !email.trim() || !message.trim()) {
      setError('Please fill in your name, email, and message details.');
      return;
    }

    setIsSubmitting(true);
    try {
      const res = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, category, subject, message }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to submit contact message.');
      }

      setResponseInfo({ ticketId: data.ticketId, message: data.message });
      setName('');
      setEmail('');
      setSubject('');
      setMessage('');
    } catch (err: any) {
      setError(err.message || 'An unexpected error occurred. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Support & Communications
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Contact Our Engineering Team
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Need assistance with a media URL, reporting a platform issue, or have a DMCA notice? Submit a request below.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-12 gap-8">
        {/* Info Column */}
        <div className="md:col-span-5 space-y-6">
          <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200 space-y-4">
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900">
              Direct Contact Channels
            </h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
              Our infrastructure specialists review incoming reports 7 days a week.
            </p>

            <div className="space-y-3 pt-2">
              <div className="flex items-center gap-3 text-xs text-neutral-300 dark:text-neutral-300 text-neutral-700">
                <Mail className="w-4 h-4 text-[#E51B2B]" />
                <span>support@veloza-yt.io</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-neutral-300 dark:text-neutral-300 text-neutral-700">
                <Clock className="w-4 h-4 text-[#176BCE]" />
                <span>Average response: &lt; 24 hours</span>
              </div>
              <div className="flex items-center gap-3 text-xs text-neutral-300 dark:text-neutral-300 text-neutral-700">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Encrypted ticket routing</span>
              </div>
            </div>
          </div>

          <div className="p-5 rounded-2xl bg-[#0f1118] border border-neutral-800 text-xs text-neutral-400 leading-relaxed">
            <span className="font-bold text-white block mb-1">Copyright & DMCA Inquiries:</span>
            Please select "Copyright / DMCA Takedown" in the category dropdown and include exact content URLs for expedited 12-hour review.
          </div>
        </div>

        {/* Form Column */}
        <div className="md:col-span-7">
          <div className="p-6 sm:p-8 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
            {responseInfo ? (
              <div className="p-6 text-center space-y-4">
                <div className="w-12 h-12 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto">
                  <CheckCircle2 className="w-6 h-6" />
                </div>
                <h3 className="text-lg font-bold text-white dark:text-white text-neutral-900">
                  Ticket Generated #{responseInfo.ticketId}
                </h3>
                <p className="text-xs text-neutral-300 dark:text-neutral-300 text-neutral-600 leading-relaxed">
                  {responseInfo.message}
                </p>
                <button
                  onClick={() => setResponseInfo(null)}
                  className="px-4 py-2 bg-neutral-800 hover:bg-neutral-700 text-white rounded-lg text-xs font-semibold cursor-pointer"
                >
                  Send Another Inquiry
                </button>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-4">
                {error && (
                  <div className="p-3 rounded-xl bg-red-950/40 border border-red-800/40 text-red-200 text-xs flex items-center gap-2">
                    <AlertCircle className="w-4 h-4 text-red-400 shrink-0" />
                    <span>{error}</span>
                  </div>
                )}

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700 mb-1">
                      Full Name *
                    </label>
                    <input
                      type="text"
                      required
                      value={name}
                      onChange={(e) => setName(e.target.value)}
                      placeholder="Jane Doe"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#08090D] dark:bg-[#08090D] bg-neutral-100 border border-neutral-700 dark:border-neutral-700 border-neutral-300 text-xs text-white dark:text-white text-neutral-900 focus:outline-none focus:border-[#E51B2B]"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700 mb-1">
                      Email Address *
                    </label>
                    <input
                      type="email"
                      required
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      placeholder="jane@example.com"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#08090D] dark:bg-[#08090D] bg-neutral-100 border border-neutral-700 dark:border-neutral-700 border-neutral-300 text-xs text-white dark:text-white text-neutral-900 focus:outline-none focus:border-[#E51B2B]"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700 mb-1">
                      Inquiry Category
                    </label>
                    <select
                      value={category}
                      onChange={(e) => setCategory(e.target.value)}
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#08090D] dark:bg-[#08090D] bg-neutral-100 border border-neutral-700 dark:border-neutral-700 border-neutral-300 text-xs text-white dark:text-white text-neutral-900 focus:outline-none focus:border-[#E51B2B]"
                    >
                      <option value="technical">Technical Support</option>
                      <option value="url_failure">Broken or Unsupported URL</option>
                      <option value="dmca">Copyright / DMCA Takedown</option>
                      <option value="feature">Feature Suggestion</option>
                      <option value="other">General Inquiries</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700 mb-1">
                      Subject
                    </label>
                    <input
                      type="text"
                      value={subject}
                      onChange={(e) => setSubject(e.target.value)}
                      placeholder="e.g. 4K stream query"
                      className="w-full px-3.5 py-2.5 rounded-xl bg-[#08090D] dark:bg-[#08090D] bg-neutral-100 border border-neutral-700 dark:border-neutral-700 border-neutral-300 text-xs text-white dark:text-white text-neutral-900 focus:outline-none focus:border-[#E51B2B]"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700 mb-1">
                    Message *
                  </label>
                  <textarea
                    required
                    rows={4}
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    placeholder="Describe your inquiry or provide the video link..."
                    className="w-full px-3.5 py-2.5 rounded-xl bg-[#08090D] dark:bg-[#08090D] bg-neutral-100 border border-neutral-700 dark:border-neutral-700 border-neutral-300 text-xs text-white dark:text-white text-neutral-900 focus:outline-none focus:border-[#E51B2B]"
                  />
                </div>

                <button
                  type="submit"
                  disabled={isSubmitting}
                  className="w-full py-3 px-4 bg-[#E51B2B] hover:bg-[#c91524] text-white font-bold rounded-xl text-xs flex items-center justify-center gap-2 cursor-pointer transition-all disabled:opacity-60"
                >
                  <Send className="w-3.5 h-3.5" />
                  {isSubmitting ? 'Transmitting Request...' : 'Submit Support Ticket'}
                </button>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
