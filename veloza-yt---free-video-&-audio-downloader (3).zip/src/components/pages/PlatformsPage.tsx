import React, { useState, useEffect } from 'react';
import { PlatformItem } from '../../types';
import { ShieldCheck, Info, CheckCircle2, AlertTriangle, ExternalLink } from 'lucide-react';

export const PlatformsPage: React.FC = () => {
  const [platforms, setPlatforms] = useState<PlatformItem[]>([]);
  const [filter, setFilter] = useState<'all' | 'supported' | 'restricted' | 'unsupported_drm'>('all');

  useEffect(() => {
    fetch('/api/platforms')
      .then((res) => res.json())
      .then((data) => {
        if (data && data.platforms) {
          setPlatforms(data.platforms);
        }
      })
      .catch(() => {
        // Fallback default list if API offline
        setPlatforms([
          {
            id: 'youtube',
            name: 'YouTube & Shorts',
            category: 'supported',
            badge: '4K / 1080p / 320k',
            status: 'Operational',
            description: 'Supports standard videos, Shorts, premieres, and audio extractions in up to 4K Ultra HD.',
            formats: ['4K Ultra HD', '2K QHD', '1080p 60fps', '720p', 'MP3 320kbps', 'M4A'],
            notes: 'Public videos only. Age-restricted or paid rentals require sign-in on official YouTube app.',
          },
          {
            id: 'tiktok',
            name: 'TikTok',
            category: 'supported',
            badge: 'Watermark-Free HD',
            status: 'Operational',
            description: 'Download HD TikTok video clips and audio tracks without watermark overlays.',
            formats: ['1080p Full HD', '720p HD', 'MP3 Original Sound'],
            notes: 'Vertical 9:16 aspect ratio preserved automatically.',
          },
          {
            id: 'instagram',
            name: 'Instagram Reels & Video',
            category: 'restricted',
            badge: '1080p Reels',
            status: 'Requires Auth',
            description: 'Fast extraction of public Instagram Reels, feed videos, and audio tracks.',
            formats: ['1080p', '720p', 'MP3'],
            notes: 'Private accounts require explicit user authorization.',
          },
        ]);
      });
  }, []);

  const filtered = filter === 'all' ? platforms : platforms.filter((p) => p.category === filter);

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      {/* Title */}
      <div className="text-center max-w-3xl mx-auto mb-10">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Platform Directory & Compatibility
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Supported Social & Video Platforms
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          VELOZA YT features modular platform parsers engineered to respect platform terms while providing the highest fidelity authorized downloads.
        </p>

        {/* Filter Tabs */}
        <div className="flex items-center justify-center gap-2 p-1 rounded-xl bg-neutral-900 dark:bg-neutral-900 bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-200 max-w-lg mx-auto mt-6">
          <button
            onClick={() => setFilter('all')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'all' ? 'bg-[#E51B2B] text-white shadow-sm' : 'text-neutral-400 hover:text-white'
            }`}
          >
            All Platforms
          </button>
          <button
            onClick={() => setFilter('supported')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'supported' ? 'bg-emerald-600 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Operational
          </button>
          <button
            onClick={() => setFilter('restricted')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'restricted' ? 'bg-amber-600 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
            }`}
          >
            Requires Auth
          </button>
          <button
            onClick={() => setFilter('unsupported_drm')}
            className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all cursor-pointer ${
              filter === 'unsupported_drm' ? 'bg-red-700 text-white shadow-sm' : 'text-neutral-400 hover:text-white'
            }`}
          >
            DRM Protected
          </button>
        </div>
      </div>

      {/* Compliance Notice Banner */}
      <div className="mb-10 p-4 sm:p-5 rounded-2xl bg-neutral-900/60 dark:bg-neutral-900/60 bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-300 flex items-start gap-3.5">
        <Info className="w-5 h-5 text-[#176BCE] shrink-0 mt-0.5" />
        <div className="text-xs text-neutral-300 dark:text-neutral-300 text-neutral-700 leading-relaxed">
          <span className="font-bold block text-white dark:text-white text-neutral-900 mb-1">
            Fair Use & Platform Security Policy
          </span>
          VELOZA YT operates within the scope of publicly accessible media APIs. We do not circumvent DRM protections (such as Widevine or FairPlay), private password gates, or paywalls. Content marked private by authors remains strictly protected.
        </div>
      </div>

      {/* Platforms Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((p) => {
          const isDrm = p.category === 'unsupported_drm';
          const isRestricted = p.category === 'restricted';

          return (
            <div
              key={p.id}
              className={`p-6 rounded-2xl border flex flex-col justify-between transition-all ${
                isDrm
                  ? 'bg-red-950/20 border-red-800/40'
                  : isRestricted
                  ? 'bg-amber-950/15 border-amber-800/40'
                  : 'bg-[#11131A] dark:bg-[#11131A] bg-white border-neutral-800 dark:border-neutral-800 border-neutral-200'
              }`}
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-3">
                  <h3 className="text-base font-bold text-white dark:text-white text-neutral-900">
                    {p.name}
                  </h3>
                  <span
                    className={`text-[10px] px-2 py-0.5 rounded font-bold border ${
                      isDrm
                        ? 'bg-red-500/20 text-red-400 border-red-500/30'
                        : isRestricted
                        ? 'bg-amber-500/20 text-amber-400 border-amber-500/30'
                        : 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30'
                    }`}
                  >
                    {p.status}
                  </span>
                </div>

                <span className="text-[11px] font-semibold text-[#E51B2B] block mb-2">
                  {p.badge}
                </span>

                <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed mb-4">
                  {p.description}
                </p>

                {/* Formats list */}
                {p.formats && p.formats.length > 0 && (
                  <div className="mb-4">
                    <span className="text-[10px] font-bold text-neutral-400 uppercase tracking-wider block mb-1.5">
                      Available Formats:
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {p.formats.map((fmt, i) => (
                        <span
                          key={i}
                          className="text-[10px] px-2 py-0.5 rounded bg-neutral-900 dark:bg-neutral-900 bg-neutral-100 text-neutral-300 dark:text-neutral-300 text-neutral-700 border border-neutral-800 dark:border-neutral-800 border-neutral-200"
                        >
                          {fmt}
                        </span>
                      ))}
                    </div>
                  </div>
                )}

                {/* DRM Legal reasons */}
                {p.legalReason && (
                  <div className="mb-2 text-[11px] text-red-300 flex items-start gap-1.5">
                    <AlertTriangle className="w-3.5 h-3.5 text-red-400 shrink-0 mt-0.5" />
                    <span>{p.legalReason}</span>
                  </div>
                )}
              </div>

              {/* Notes or Authorized alternative */}
              {p.notes && (
                <div className="pt-3 border-t border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200 text-[11px] text-neutral-400 dark:text-neutral-400 text-neutral-500 flex items-start gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5 text-amber-400 shrink-0 mt-0.5" />
                  <span>{p.notes}</span>
                </div>
              )}
              {p.authorizedAlternative && (
                <div className="pt-2 text-[11px] text-emerald-400 flex items-start gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5 shrink-0 mt-0.5" />
                  <span>{p.authorizedAlternative}</span>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};
