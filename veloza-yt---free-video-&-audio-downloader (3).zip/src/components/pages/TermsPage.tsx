import React from 'react';
import { FileText, ShieldAlert, CheckCircle, Scale } from 'lucide-react';

export const TermsPage: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      <div className="text-center max-w-2xl mx-auto mb-12">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          Usage Agreement
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Terms of Service
        </h1>
        <p className="text-sm text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          Please review these terms before using the VELOZA YT platform.
        </p>
      </div>

      <div className="space-y-6 text-neutral-300 dark:text-neutral-300 text-neutral-700 text-xs sm:text-sm leading-relaxed">
        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2 flex items-center gap-2">
            <Scale className="w-4 h-4 text-[#E51B2B]" />
            1. Acceptable Personal Use
          </h2>
          <p>
            VELOZA YT is provided as a utility for personal offline archiving, educational evaluation, and fair-use access to publicly available web media. Users are strictly responsible for adhering to applicable copyright laws and the terms of service of respective media providers.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2 flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            2. Prohibited Uses
          </h2>
          <p>
            You agree not to use VELOZA YT to:
          </p>
          <ul className="list-disc pl-5 mt-2 space-y-1 text-neutral-400 dark:text-neutral-400 text-neutral-600">
            <li>Circumvent or attempt to disable digital rights management (DRM) technologies or private encryption gates.</li>
            <li>Download content intended for commercial redistribution, resale, or unauthorized public performance.</li>
            <li>Overload, spam, or perform automated denial-of-service operations against VELOZA YT infrastructure.</li>
            <li>Distribute defamatory, unlawful, or copyrighted media without clear statutory fair-use defense or authorization.</li>
          </ul>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <h2 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2 flex items-center gap-2">
            <CheckCircle className="w-4 h-4 text-[#176BCE]" />
            3. Disclaimer of Warranties
          </h2>
          <p>
            The service is provided on an "as is" and "as available" basis without warranties of any kind. VELOZA YT does not guarantee uninterrupted availability, zero server downtime, or perpetual support for any specific external website.
          </p>
        </div>
      </div>
    </div>
  );
};
