import React from 'react';
import { Shield, Zap, Globe, Heart, Award, Cpu, CheckCircle } from 'lucide-react';

export const AboutPage: React.FC = () => {
  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
      {/* Page Header */}
      <div className="text-center max-w-3xl mx-auto mb-16">
        <span className="text-xs font-bold uppercase tracking-widest text-[#E51B2B] mb-2 block">
          About Our Mission
        </span>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight mb-4">
          Empowering Media Freedom Worldwide
        </h1>
        <p className="text-base text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
          VELOZA YT was built on a simple premise: individuals, researchers, offline creators, and educators should have reliable, high-speed access to authorized media in its finest resolution.
        </p>
      </div>

      {/* Grid of Principles */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16">
        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <div className="w-10 h-10 rounded-xl bg-[#E51B2B]/10 border border-[#E51B2B]/30 flex items-center justify-center text-[#E51B2B] mb-4">
            <Zap className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
            Zero Artificial Throttling
          </h3>
          <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
            Unlike legacy converter utilities that intentionally bottleneck download speeds to upsell "VIP passes", VELOZA YT provides full unthrottled bandwidth up to your local ISP capacity.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <div className="w-10 h-10 rounded-xl bg-[#176BCE]/10 border border-[#176BCE]/30 flex items-center justify-center text-[#176BCE] mb-4">
            <Shield className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
            Strict Privacy & No Logs
          </h3>
          <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
            We never store your personal identifiers, IP addresses, or browsing history. Media URLs pass through ephemeral processing buffers that self-destruct once delivery is complete.
          </p>
        </div>

        <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200">
          <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 mb-4">
            <Heart className="w-5 h-5" />
          </div>
          <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
            Free Access Model
          </h3>
          <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
            We do not believe in bait-and-switch billing, hidden fees, or compulsory credit card registration for basic media saving. Core functionality is 100% free for everyone.
          </p>
        </div>
      </div>

      {/* Engineering Story */}
      <div className="p-8 sm:p-10 rounded-3xl bg-[#0f1118] border border-neutral-800 space-y-6 text-sm text-neutral-300 leading-relaxed">
        <h2 className="text-xl sm:text-2xl font-bold text-white">
          Our Architectural Philosophy
        </h2>
        <p>
          Media processing on the modern web is riddled with low-quality web tools filled with intrusive pop-up advertisements, deceptive fake "download" buttons, and malware vectors. VELOZA YT was engineered to set an international standard for clean, trustworthy, high-performance web tooling.
        </p>
        <p>
          By leveraging modern containerized FFmpeg pipelines, distributed edge caches, and modern browser APIs, we enable users to analyze and download complex media formats—including 4K Ultra HD at 60 FPS, multi-track streams, and studio 320 kbps MP3 acoustics—with minimal server latency.
        </p>

        <div className="pt-4 border-t border-neutral-800 grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div>
            <span className="text-2xl font-extrabold text-[#E51B2B] block">4K 60FPS</span>
            <span className="text-xs text-neutral-400">Max Video Quality</span>
          </div>
          <div>
            <span className="text-2xl font-extrabold text-[#176BCE] block">320 kbps</span>
            <span className="text-xs text-neutral-400">Pure Audio Bitrate</span>
          </div>
          <div>
            <span className="text-2xl font-extrabold text-emerald-400 block">10+</span>
            <span className="text-xs text-neutral-400">Platforms Supported</span>
          </div>
          <div>
            <span className="text-2xl font-extrabold text-white block">0</span>
            <span className="text-xs text-neutral-400">Mandatory Accounts</span>
          </div>
        </div>
      </div>
    </div>
  );
};
