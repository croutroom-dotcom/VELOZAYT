import React from 'react';
import { PageView } from '../types';
import { ShieldCheck, Lock, Activity, Heart } from 'lucide-react';

interface FooterProps {
  onNavigate: (page: PageView) => void;
}

export const Footer: React.FC<FooterProps> = ({ onNavigate }) => {
  const handleNav = (p: PageView) => {
    onNavigate(p);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="w-full bg-[#050608] border-t border-neutral-800 text-neutral-400 text-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-8 mb-12">
          {/* Col 1: Brand Info */}
          <div className="lg:col-span-2 space-y-3">
            <div className="flex items-center gap-2.5">
              <div className="w-7 h-7 rounded-lg bg-gradient-to-br from-[#7C5CFF] to-[#9B82FF] flex items-center justify-center font-black text-white text-xs shadow-sm shadow-[#7C5CFF]/30">
                V
              </div>
              <span className="text-lg font-extrabold tracking-tight text-[#F5F5F7]">
                VELOZA <span className="text-[#7C5CFF]">YT</span>
              </span>
            </div>
            <p className="text-neutral-400 text-xs leading-relaxed max-w-sm">
              Free, professional video and audio downloading utility. Engineered for 4K Ultra HD clarity, 320kbps MP3 fidelity, and zero rate-limiting restrictions.
            </p>
            <div className="flex items-center gap-4 text-[11px] text-neutral-400 pt-2">
              <span className="flex items-center gap-1.5">
                <Lock className="w-3.5 h-3.5 text-emerald-400" />
                256-Bit SSL Encrypted
              </span>
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-3.5 h-3.5 text-[#176BCE]" />
                Zero User Tracking
              </span>
            </div>
          </div>

          {/* Col 2: Core Platform */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Downloader</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-white transition-colors cursor-pointer">
                  Online Video Downloader
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-white transition-colors cursor-pointer">
                  YouTube 4K Downloader
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('home')} className="hover:text-white transition-colors cursor-pointer">
                  MP3 Audio Extractor
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('features')} className="hover:text-white transition-colors cursor-pointer">
                  Features & Specifications
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('platforms')} className="hover:text-white transition-colors cursor-pointer">
                  Supported Platforms
                </button>
              </li>
            </ul>
          </div>

          {/* Col 3: Resources & Guides */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Resources & QA</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleNav('guide')} className="hover:text-white transition-colors cursor-pointer">
                  How to Download (Guide)
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('faq')} className="hover:text-white transition-colors cursor-pointer">
                  Frequently Asked Questions
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('diagnostics')} className="text-[#7C5CFF] hover:underline flex items-center gap-1 transition-colors cursor-pointer font-semibold">
                  <Activity className="w-3.5 h-3.5" />
                  System Audit & Diagnostics
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('about')} className="hover:text-white transition-colors cursor-pointer">
                  About VELOZA YT
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('contact')} className="hover:text-white transition-colors cursor-pointer">
                  Contact & Support
                </button>
              </li>
            </ul>
          </div>

          {/* Col 4: Legal & Compliance */}
          <div>
            <h4 className="text-white font-bold text-xs uppercase tracking-wider mb-3">Legal & DMCA</h4>
            <ul className="space-y-2">
              <li>
                <button onClick={() => handleNav('privacy')} className="hover:text-white transition-colors cursor-pointer">
                  Privacy Policy
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('terms')} className="hover:text-white transition-colors cursor-pointer">
                  Terms of Service
                </button>
              </li>
              <li>
                <button onClick={() => handleNav('copyright')} className="hover:text-white transition-colors cursor-pointer">
                  Copyright & DMCA Policy
                </button>
              </li>
            </ul>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-neutral-800/80 flex flex-col sm:flex-row items-center justify-between gap-4 text-[11px] text-neutral-400">
          <div>
            © {new Date().getFullYear()} VELOZA YT. Videos. Audio. Your Way. All rights reserved.
          </div>
          <div className="flex items-center gap-4">
            <span>Free Public Media Utility</span>
            <span>·</span>
            <span>Sustainable Free Model</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
