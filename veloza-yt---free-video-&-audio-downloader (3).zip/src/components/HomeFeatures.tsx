import React from 'react';
import {
  Sparkles,
  Zap,
  ShieldCheck,
  Headphones,
  Maximize2,
  Cpu,
  CheckCircle2,
  ArrowRight,
  Tv,
} from 'lucide-react';
import { PageView } from '../types';

interface HomeFeaturesProps {
  onNavigate: (page: PageView) => void;
  onFocusInput: () => void;
}

export const HomeFeatures: React.FC<HomeFeaturesProps> = ({ onNavigate, onFocusInput }) => {
  return (
    <div className="w-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16 space-y-20">
      {/* 1. How It Works 3-Step Section */}
      <section>
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs font-bold uppercase tracking-widest text-[#7C5CFF] mb-2 block">
            Simple 3-Step Workflow
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight">
            How to Download Any Video or Audio
          </h2>
          <p className="text-neutral-400 dark:text-neutral-400 text-neutral-600 text-sm mt-2">
            No software installation. No mandatory registrations. Just lightning-fast media processing.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-300 relative group hover:border-[#7C5CFF]/50 transition-all">
            <div className="w-10 h-10 rounded-xl bg-[#7C5CFF]/15 border border-[#7C5CFF]/30 flex items-center justify-center text-[#7C5CFF] font-extrabold text-lg mb-4">
              1
            </div>
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
              Copy & Paste Media Link
            </h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
              Copy the video URL from YouTube, TikTok, Instagram Reels, Facebook, or direct link and paste into our input field.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-300 relative group hover:border-[#176BCE]/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-[#176BCE]/10 border border-[#176BCE]/30 flex items-center justify-center text-[#176BCE] font-extrabold text-lg mb-4">
              2
            </div>
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
              Choose Resolution or Format
            </h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
              Select your preferred visual quality (4K Ultra HD, 2K, 1080p, 720p) or extract studio 320kbps MP3 audio.
            </p>
          </div>

          <div className="p-6 rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-300 relative group hover:border-emerald-500/40 transition-all">
            <div className="w-10 h-10 rounded-xl bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400 font-extrabold text-lg mb-4">
              3
            </div>
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900 mb-2">
              Direct High-Speed Download
            </h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-600 leading-relaxed">
              Receive your verified media file immediately without throttling, annoying countdowns, or deceptive ads.
            </p>
          </div>
        </div>
      </section>

      {/* 2. Visual Audio & 4K Capabilities Split */}
      <section className="rounded-3xl bg-[#0f1118] border border-neutral-800 overflow-hidden shadow-2xl">
        <div className="grid grid-cols-1 lg:grid-cols-12 items-stretch">
          {/* Left Text Column */}
          <div className="lg:col-span-6 p-8 sm:p-12 flex flex-col justify-between">
            <div>
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-[#176BCE] mb-3">
                <Headphones className="w-4 h-4" />
                <span>Audiophile Studio Extraction</span>
              </div>
              <h2 className="text-2xl sm:text-3xl font-extrabold text-white tracking-tight leading-snug mb-4">
                Pristine 320 kbps MP3 & Lossless Audio Clarity
              </h2>
              <p className="text-sm text-neutral-300 leading-relaxed mb-6">
                VELOZA YT features a dedicated high-fidelity audio extraction engine. Convert your favorite music videos, podcast discussions, speeches, and sound effects into clean stereo MP3 at constant 320kbps or AAC M4A without loss of dynamic range.
              </p>

              <div className="space-y-3 mb-8">
                <div className="flex items-center gap-3 text-xs text-neutral-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Full 48kHz frequency spectrum preservation without muffled highs</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-neutral-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>ID3 metadata tagging included automatically</span>
                </div>
                <div className="flex items-center gap-3 text-xs text-neutral-300">
                  <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
                  <span>Compatible with iPhone, Android, car audio systems & hi-fi setups</span>
                </div>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <button
                onClick={onFocusInput}
                className="px-5 py-2.5 bg-[#7C5CFF] hover:bg-[#6c48ff] text-[#F5F5F7] text-xs font-bold rounded-xl transition-all shadow-md shadow-[#7C5CFF]/30 cursor-pointer"
              >
                Try Audio Extraction
              </button>
              <button
                onClick={() => onNavigate('features')}
                className="text-xs text-neutral-300 hover:text-white flex items-center gap-1 font-semibold transition-colors cursor-pointer"
              >
                Learn Audio Architecture <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>

          {/* Right Image Column */}
          <div className="lg:col-span-6 relative min-h-[300px] lg:min-h-full bg-neutral-900 overflow-hidden">
            <img
              src="/src/assets/images/audio_waveform_studio_1793358943517.jpg"
              alt="High Quality Audio Studio Waveform Visualizer"
              referrerPolicy="no-referrer"
              className="w-full h-full object-cover object-center"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent lg:bg-gradient-to-l lg:from-transparent lg:to-[#0f1118]" />
            <div className="absolute bottom-6 left-6 right-6 p-4 rounded-xl bg-black/70 backdrop-blur-md border border-neutral-700/60">
              <span className="text-[11px] font-bold text-white block">Acoustic Precision</span>
              <span className="text-[10px] text-neutral-400">Zero dynamic compression artifacts with real-time waveform inspection</span>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Platform Compatibility Quick Carousel / Grid */}
      <section className="text-center">
        <div className="max-w-2xl mx-auto mb-8">
          <span className="text-xs font-bold uppercase tracking-widest text-[#7C5CFF] mb-2 block">
            Modular Platform Engine
          </span>
          <h2 className="text-2xl sm:text-3xl font-extrabold text-white dark:text-white text-neutral-900 tracking-tight">
            Universal Social & Video Network Compatibility
          </h2>
          <p className="text-neutral-400 dark:text-neutral-400 text-neutral-600 text-sm mt-2">
            Seamlessly handles YouTube Shorts, long-form 4K video, TikTok vertical clips, Instagram Reels, and direct media streams.
          </p>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {[
            { name: 'YouTube', type: '4K & Shorts', color: '#7C5CFF' },
            { name: 'TikTok', type: 'No Watermark', color: '#00F2FE' },
            { name: 'Instagram', type: 'Reels & Video', color: '#E1306C' },
            { name: 'Facebook', type: 'Watch & Clips', color: '#1877F2' },
            { name: 'X / Twitter', type: 'HD Video & GIF', color: '#1DA1F2' },
            { name: 'Vimeo', type: 'Cinema 4K', color: '#1AB7EA' },
          ].map((item, idx) => (
            <div
              key={idx}
              className="p-4 rounded-xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-200 text-center hover:border-neutral-700 transition-colors"
            >
              <div
                className="w-8 h-8 rounded-lg mx-auto mb-2 flex items-center justify-center font-black text-xs text-white"
                style={{ backgroundColor: item.color }}
              >
                {item.name[0]}
              </div>
              <h4 className="text-xs font-bold text-white dark:text-white text-neutral-900">{item.name}</h4>
              <span className="text-[10px] text-neutral-400 dark:text-neutral-400 text-neutral-500">{item.type}</span>
            </div>
          ))}
        </div>

        <div className="mt-6">
          <button
            onClick={() => onNavigate('platforms')}
            className="text-xs font-bold text-[#7C5CFF] hover:underline inline-flex items-center gap-1 cursor-pointer"
          >
            Explore all 10+ supported platforms and technical limits <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      </section>

      {/* 4. Quality Matrix Table */}
      <section className="rounded-2xl bg-[#11131A] dark:bg-[#11131A] bg-white border border-neutral-800 dark:border-neutral-800 border-neutral-300 p-6 sm:p-8">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 mb-6">
          <div>
            <h3 className="text-lg font-bold text-white dark:text-white text-neutral-900">
              Media Resolution & Bitrate Specifications
            </h3>
            <p className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500 mt-1">
              Real resolution standards processed through VELOZA YT
            </p>
          </div>
          <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-neutral-900 dark:bg-neutral-900 bg-neutral-100 text-neutral-400 border border-neutral-800 dark:border-neutral-800 border-neutral-200">
            FFmpeg Engine v7.1
          </span>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b border-neutral-800 dark:border-neutral-800 border-neutral-200 text-neutral-400">
                <th className="py-3 px-3 font-semibold">Quality Tier</th>
                <th className="py-3 px-3 font-semibold">Pixel Resolution</th>
                <th className="py-3 px-3 font-semibold">Frame Rate</th>
                <th className="py-3 px-3 font-semibold">Video Codec</th>
                <th className="py-3 px-3 font-semibold">Audio Track</th>
                <th className="py-3 px-3 font-semibold text-right">Ideal Device</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-neutral-800/60 dark:divide-neutral-800/60 divide-neutral-200 text-neutral-300 dark:text-neutral-300 text-neutral-700">
              <tr>
                <td className="py-3 px-3 font-bold text-white dark:text-white text-neutral-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#7C5CFF]" />
                  4K Ultra HD
                </td>
                <td className="py-3 px-3 font-mono">3840 x 2160</td>
                <td className="py-3 px-3 font-mono">60 FPS</td>
                <td className="py-3 px-3">AV1 / VP9 / H.264</td>
                <td className="py-3 px-3">320 kbps Stereo</td>
                <td className="py-3 px-3 text-right">4K Smart TV & Cinema Displays</td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white dark:text-white text-neutral-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-[#176BCE]" />
                  2K Quad HD
                </td>
                <td className="py-3 px-3 font-mono">2560 x 1440</td>
                <td className="py-3 px-3 font-mono">60 FPS</td>
                <td className="py-3 px-3">H.264 / VP9</td>
                <td className="py-3 px-3">256 kbps Stereo</td>
                <td className="py-3 px-3 text-right">Pro Studio Monitors & Laptops</td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white dark:text-white text-neutral-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-emerald-400" />
                  1080p Full HD
                </td>
                <td className="py-3 px-3 font-mono">1920 x 1080</td>
                <td className="py-3 px-3 font-mono">60 / 30 FPS</td>
                <td className="py-3 px-3">H.264 High Profile</td>
                <td className="py-3 px-3">256 kbps Stereo</td>
                <td className="py-3 px-3 text-right">Smartphones, Tablets & Desktops</td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white dark:text-white text-neutral-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-neutral-400" />
                  720p HD
                </td>
                <td className="py-3 px-3 font-mono">1280 x 720</td>
                <td className="py-3 px-3 font-mono">30 FPS</td>
                <td className="py-3 px-3">H.264 Baseline</td>
                <td className="py-3 px-3">192 kbps</td>
                <td className="py-3 px-3 text-right">Low-bandwidth Cellular & Mobile</td>
              </tr>
              <tr>
                <td className="py-3 px-3 font-bold text-white dark:text-white text-neutral-900 flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-purple-400" />
                  Studio MP3
                </td>
                <td className="py-3 px-3 font-mono">Acoustic Audio</td>
                <td className="py-3 px-3 font-mono">48 kHz</td>
                <td className="py-3 px-3">MPEG Audio Layer 3</td>
                <td className="py-3 px-3">320 kbps Constant</td>
                <td className="py-3 px-3 text-right">Studio Headphones & Car Audio</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>
    </div>
  );
};
