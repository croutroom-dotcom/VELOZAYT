import React, { useState, useRef, useEffect } from 'react';
import { Search, Clipboard, X, Loader2, Sparkles, CheckCircle2, AlertCircle } from 'lucide-react';
import { MediaMetadata } from '../types';

interface DownloaderEngineProps {
  onMediaAnalyzed: (data: MediaMetadata) => void;
  isLoading: boolean;
  setIsLoading: (val: boolean) => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
}

export const DownloaderEngine: React.FC<DownloaderEngineProps> = ({
  onMediaAnalyzed,
  isLoading,
  setIsLoading,
  inputRef,
}) => {
  const [url, setUrl] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  // Sample quick test links
  const sampleLinks = [
    {
      label: '4K Ultra HD Sample',
      url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4',
      badge: '4K 60FPS',
    },
    {
      label: '1080p Studio Tech Clip',
      url: 'https://www.w3schools.com/html/mov_bbb.mp4',
      badge: '1080p HD',
    },
    {
      label: '320kbps Spatial Audio',
      url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-audio/t-rex-roar.mp3',
      badge: '320k MP3',
    },
  ];

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text);
        setError(null);
        handleAnalyzeUrl(text);
      }
    } catch {
      setError('Clipboard access was denied. Please paste the URL manually.');
    }
  };

  const handleAnalyzeUrl = async (targetUrl?: string) => {
    const raw = targetUrl || url;
    if (!raw.trim()) {
      setError('Please enter a valid video or audio URL.');
      return;
    }

    setError(null);
    setSuccessNotice(null);
    setIsLoading(true);

    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: raw.trim() }),
      });

      const resData = await response.json();

      if (!response.ok || !resData.success) {
        throw new Error(resData.error || 'Failed to analyze media link.');
      }

      onMediaAnalyzed(resData.data);
      setSuccessNotice(`Media analyzed successfully: "${resData.data.title}"`);
    } catch (err: any) {
      setError(err.message || 'An error occurred while connecting to the media server.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleAnalyzeUrl();
  };

  return (
    <div className="w-full max-w-4xl mx-auto -mt-6 sm:-mt-8 relative z-20 px-4">
      <div className="bg-[#11131A] dark:bg-[#11131A] bg-white rounded-2xl p-4 sm:p-6 border border-neutral-800 dark:border-neutral-800 border-neutral-300 shadow-2xl glow-subtle">
        {/* Form Container */}
        <form onSubmit={handleSubmit} className="relative flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none text-neutral-400">
              <Search className="w-5 h-5 text-neutral-400" />
            </div>

            <input
              ref={inputRef}
              type="text"
              value={url}
              onChange={(e) => {
                setUrl(e.target.value);
                if (error) setError(null);
              }}
              placeholder="Paste YouTube, TikTok, Instagram, Vimeo, or direct video/audio link..."
              className="w-full pl-11 pr-24 py-4 rounded-xl bg-[#08090D] dark:bg-[#08090D] bg-neutral-50 text-white dark:text-white text-neutral-900 border border-neutral-700 dark:border-neutral-700 border-neutral-300 focus:border-[#7C5CFF] focus:ring-2 focus:ring-[#7C5CFF]/30 text-sm sm:text-base outline-none transition-all placeholder:text-neutral-500"
              aria-label="Media URL input"
            />

            {/* Clear or Paste inside input */}
            <div className="absolute inset-y-0 right-2 flex items-center gap-1.5">
              {url ? (
                <button
                  type="button"
                  onClick={() => setUrl('')}
                  className="p-1.5 text-neutral-400 hover:text-white rounded-md transition-colors cursor-pointer"
                  title="Clear input"
                >
                  <X className="w-4 h-4" />
                </button>
              ) : (
                <button
                  type="button"
                  onClick={handlePaste}
                  className="px-2.5 py-1.5 text-xs font-medium text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:text-white dark:hover:text-white bg-neutral-800 dark:bg-neutral-800 bg-neutral-200 rounded-lg hover:bg-neutral-700 transition-colors flex items-center gap-1 cursor-pointer"
                  title="Paste from clipboard"
                >
                  <Clipboard className="w-3.5 h-3.5" />
                  <span className="hidden xs:inline">Paste</span>
                </button>
              )}
            </div>
          </div>

          {/* Action Button */}
          <button
            type="submit"
            disabled={isLoading}
            className="w-full sm:w-auto px-8 py-4 bg-[#7C5CFF] hover:bg-[#6c48ff] text-[#F5F5F7] font-bold rounded-xl shadow-lg shadow-[#7C5CFF]/30 hover:shadow-[#7C5CFF]/50 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 disabled:cursor-not-allowed whitespace-nowrap active:scale-95"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-5 h-5 animate-spin" />
                Analyzing...
              </>
            ) : (
              <>
                <Sparkles className="w-5 h-5" />
                Analyze Stream
              </>
            )}
          </button>
        </form>

        {/* Quick Sample Links Strip */}
        <div className="mt-4 pt-4 border-t border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2 text-neutral-400">
            <span className="font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700">Quick Test:</span>
            <div className="flex flex-wrap items-center gap-1.5">
              {sampleLinks.map((item, idx) => (
                <button
                  key={idx}
                  type="button"
                  onClick={() => {
                    setUrl(item.url);
                    handleAnalyzeUrl(item.url);
                  }}
                  className="px-2.5 py-1 rounded-md bg-neutral-800/80 dark:bg-neutral-800/80 bg-neutral-100 hover:bg-neutral-700 dark:hover:bg-neutral-700 text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:text-white transition-colors cursor-pointer flex items-center gap-1.5"
                >
                  <span>{item.label}</span>
                  <span className="text-[10px] px-1 py-0.2 rounded bg-neutral-900 dark:bg-neutral-900 bg-neutral-200 text-[#7C5CFF] font-semibold">
                    {item.badge}
                  </span>
                </button>
              ))}
            </div>
          </div>
          <span className="text-neutral-500 text-[11px]">Safe, SSL encrypted direct analysis</span>
        </div>

        {/* Error notification */}
        {error && (
          <div className="mt-4 p-3 rounded-xl bg-red-950/40 border border-red-800/50 text-red-200 text-xs flex items-start gap-2.5">
            <AlertCircle className="w-4 h-4 text-[#E51B2B] shrink-0 mt-0.5" />
            <div className="flex-1">
              <span className="font-semibold block mb-0.5">Media Analysis Notice</span>
              <span>{error}</span>
            </div>
            <button onClick={() => setError(null)} className="text-red-400 hover:text-red-200">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}

        {/* Success notification */}
        {successNotice && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-950/30 border border-emerald-800/40 text-emerald-300 text-xs flex items-center justify-between gap-2.5">
            <div className="flex items-center gap-2">
              <CheckCircle2 className="w-4 h-4 text-emerald-400 shrink-0" />
              <span>{successNotice}</span>
            </div>
            <button onClick={() => setSuccessNotice(null)} className="text-emerald-400 hover:text-emerald-200">
              <X className="w-3.5 h-3.5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
