import React from 'react';
import { HistoryItem } from '../types';
import { History, Download, Trash2, ExternalLink, Film, Music2, Share2 } from 'lucide-react';

interface HistorySectionProps {
  history: HistoryItem[];
  onClearHistory: () => void;
  onDownloadAgain: (item: HistoryItem) => void;
  onCopyLink: (url: string) => void;
}

export const HistorySection: React.FC<HistorySectionProps> = ({
  history,
  onClearHistory,
  onDownloadAgain,
  onCopyLink,
}) => {
  if (history.length === 0) return null;

  return (
    <section className="w-full max-w-4xl mx-auto mt-12 px-4">
      <div className="bg-[#11131A] dark:bg-[#11131A] bg-white rounded-2xl border border-neutral-800 dark:border-neutral-800 border-neutral-300 p-6 shadow-xl">
        {/* Header */}
        <div className="flex items-center justify-between pb-4 mb-4 border-b border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200">
          <div className="flex items-center gap-2.5">
            <History className="w-5 h-5 text-[#E51B2B]" />
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900">
              Recent Downloads ({history.length})
            </h3>
            <span className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500 hidden sm:inline">
              Stored locally on your device
            </span>
          </div>

          <button
            onClick={onClearHistory}
            className="text-xs text-neutral-400 hover:text-red-400 flex items-center gap-1 transition-colors cursor-pointer"
          >
            <Trash2 className="w-3.5 h-3.5" />
            Clear History
          </button>
        </div>

        {/* Items List */}
        <div className="space-y-3">
          {history.map((item) => {
            const isAudio = item.mediaType === 'audio';
            const dateStr = new Date(item.timestamp).toLocaleDateString(undefined, {
              month: 'short',
              day: 'numeric',
              hour: '2-digit',
              minute: '2-digit',
            });

            return (
              <div
                key={item.id}
                className="p-3 rounded-xl bg-neutral-900/60 dark:bg-neutral-900/60 bg-neutral-50 border border-neutral-800 dark:border-neutral-800 border-neutral-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 transition-colors hover:border-neutral-700"
              >
                <div className="flex items-center gap-3 min-w-0 flex-1">
                  <div className="relative w-16 h-11 rounded-lg overflow-hidden bg-neutral-800 shrink-0 border border-neutral-700">
                    <img
                      src={item.thumbnail}
                      alt={item.title}
                      referrerPolicy="no-referrer"
                      className="w-full h-full object-cover"
                      onError={(e) => {
                        (e.target as HTMLImageElement).src =
                          '/src/assets/images/veloza_hero_banner_1793358943892.jpg';
                      }}
                    />
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center">
                      {isAudio ? (
                        <Music2 className="w-3.5 h-3.5 text-white" />
                      ) : (
                        <Film className="w-3.5 h-3.5 text-white" />
                      )}
                    </div>
                  </div>

                  <div className="min-w-0">
                    <h4 className="text-xs sm:text-sm font-bold text-white dark:text-white text-neutral-900 truncate">
                      {item.title}
                    </h4>
                    <div className="flex items-center gap-2 text-[11px] text-neutral-400 mt-0.5">
                      <span className="px-1.5 py-0.2 rounded bg-neutral-800 text-[#E51B2B] font-semibold">
                        {item.quality}
                      </span>
                      <span>·</span>
                      <span className="font-mono">{item.fileSize}</span>
                      <span>·</span>
                      <span>{dateStr}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex items-center gap-2 w-full sm:w-auto justify-end pt-2 sm:pt-0 border-t sm:border-t-0 border-neutral-800/60">
                  <button
                    onClick={() => onCopyLink(item.url)}
                    className="p-2 text-neutral-400 hover:text-white bg-neutral-800 dark:bg-neutral-800 bg-neutral-200 rounded-lg text-xs transition-colors cursor-pointer"
                    title="Copy URL"
                  >
                    <Share2 className="w-3.5 h-3.5" />
                  </button>

                  <button
                    onClick={() => onDownloadAgain(item)}
                    className="px-3 py-1.5 bg-[#E51B2B] hover:bg-[#c91524] text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-all shadow-sm cursor-pointer"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Again
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};
