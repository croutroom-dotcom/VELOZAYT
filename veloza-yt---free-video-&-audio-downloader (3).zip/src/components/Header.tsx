import React, { useState } from 'react';
import { PageView } from '../types';
import { Sun, Moon, Menu, X, DownloadCloud, Activity } from 'lucide-react';

interface HeaderProps {
  currentPage: PageView;
  onNavigate: (page: PageView) => void;
  darkMode: boolean;
  onToggleTheme: () => void;
  activeJobsCount: number;
  onOpenQueue: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  currentPage,
  onNavigate,
  darkMode,
  onToggleTheme,
  activeJobsCount,
  onOpenQueue,
}) => {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const navLinks: { label: string; page: PageView }[] = [
    { label: 'Downloader', page: 'home' },
    { label: 'Features', page: 'features' },
    { label: 'Platforms', page: 'platforms' },
    { label: 'Guide', page: 'guide' },
    { label: 'Audit', page: 'diagnostics' },
  ];

  const handleLinkClick = (page: PageView) => {
    onNavigate(page);
    setMobileMenuOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <header className="sticky top-0 z-40 w-full backdrop-blur-xl bg-[#08090D]/90 dark:bg-[#08090D]/90 bg-white/90 border-b border-neutral-800/60 dark:border-neutral-800/60 border-neutral-200 transition-colors">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-18 flex items-center justify-between gap-8">
        {/* Zone 1: Brand Wordmark (Single text element in display face) */}
        <button
          onClick={() => handleLinkClick('home')}
          className="flex items-center gap-2.5 text-left group cursor-pointer focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7C5CFF] rounded-lg p-1 shrink-0"
        >
          <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-[#7C5CFF] to-[#9B82FF] flex items-center justify-center shadow-md shadow-[#7C5CFF]/30 transition-transform group-hover:scale-105">
            <span className="text-white font-black text-sm tracking-tighter">V</span>
          </div>
          <span className="text-xl font-extrabold tracking-tight text-[#F5F5F7] dark:text-[#F5F5F7] text-neutral-900 whitespace-nowrap">
            VELOZA <span className="text-[#7C5CFF]">YT</span>
          </span>
        </button>

        {/* Zone 2: 4-5 Concise Single-Line Navigation Links */}
        <nav className="hidden md:flex items-center gap-7 text-sm font-medium">
          {navLinks.map((item) => {
            const isActive = currentPage === item.page;
            return (
              <button
                key={item.page}
                onClick={() => handleLinkClick(item.page)}
                className={`whitespace-nowrap transition-colors relative py-1 hover:text-[#7C5CFF] ${
                  isActive
                    ? 'text-white dark:text-white text-neutral-950 font-semibold'
                    : 'text-neutral-400 dark:text-neutral-400 text-neutral-600'
                }`}
              >
                {item.label}
                {isActive && (
                  <span className="absolute bottom-0 left-0 right-0 h-0.5 bg-[#7C5CFF] rounded-full" />
                )}
              </button>
            );
          })}
        </nav>

        {/* Zone 3: Primary Actions (Theme Toggle & Queue / Quick Action) */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Quick System Audit Button */}
          <button
            onClick={() => handleLinkClick('diagnostics')}
            className={`p-2 rounded-lg transition-colors cursor-pointer ${
              currentPage === 'diagnostics'
                ? 'text-[#7C5CFF] bg-neutral-800/80'
                : 'text-neutral-400 hover:text-white hover:bg-neutral-800/60'
            }`}
            title="System Diagnostics & Integrity Audit"
            aria-label="System Diagnostics"
          >
            <Activity className="w-5 h-5" />
          </button>

          {/* Active Queue Trigger */}
          <button
            onClick={onOpenQueue}
            className="relative p-2 rounded-lg text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:text-white dark:hover:text-white hover:bg-neutral-800/60 dark:hover:bg-neutral-800/60 hover:bg-neutral-100 transition-colors cursor-pointer"
            title="Download Queue"
            aria-label="Download Queue"
          >
            <DownloadCloud className="w-5 h-5" />
            {activeJobsCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 bg-[#7C5CFF] text-white text-[10px] font-bold rounded-full flex items-center justify-center">
                {activeJobsCount}
              </span>
            )}
          </button>

          {/* Theme Toggle */}
          <button
            onClick={onToggleTheme}
            className="p-2 rounded-lg text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:text-white dark:hover:text-white hover:bg-neutral-800/60 dark:hover:bg-neutral-800/60 hover:bg-neutral-100 transition-colors cursor-pointer"
            title={darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
            aria-label="Toggle visual theme"
          >
            {darkMode ? <Sun className="w-5 h-5 text-amber-400" /> : <Moon className="w-5 h-5 text-neutral-700" />}
          </button>

          {/* Primary CTA */}
          <button
            onClick={() => handleLinkClick('home')}
            className="hidden sm:inline-flex items-center justify-center px-4 py-2 text-xs font-semibold text-white bg-[#7C5CFF] hover:bg-[#6c48ff] rounded-lg shadow-sm shadow-[#7C5CFF]/30 transition-all hover:shadow-[#7C5CFF]/50 whitespace-nowrap cursor-pointer active:scale-95"
          >
            Free Downloader
          </button>

          {/* Mobile hamburger */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="md:hidden p-2 rounded-lg text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:bg-neutral-800/60 dark:hover:bg-neutral-800/60 hover:bg-neutral-100 transition-colors"
            aria-label="Toggle menu"
          >
            {mobileMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>
      </div>

      {/* Mobile Menu Dropdown */}
      {mobileMenuOpen && (
        <div className="md:hidden border-b border-neutral-800 dark:border-neutral-800 border-neutral-200 bg-[#08090D] dark:bg-[#08090D] bg-white px-4 pt-2 pb-6 space-y-2">
          {navLinks.map((item) => (
            <button
              key={item.page}
              onClick={() => handleLinkClick(item.page)}
              className={`w-full text-left py-2.5 px-3 rounded-lg text-sm font-medium transition-colors ${
                currentPage === item.page
                  ? 'bg-neutral-800/80 dark:bg-neutral-800/80 bg-neutral-100 text-[#7C5CFF] font-semibold'
                  : 'text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:bg-neutral-800/40 dark:hover:bg-neutral-800/40 hover:bg-neutral-50'
              }`}
            >
              {item.label}
            </button>
          ))}
          <div className="pt-2 border-t border-neutral-800 dark:border-neutral-800 border-neutral-200 flex flex-col gap-2">
            <button
              onClick={() => handleLinkClick('faq')}
              className="w-full text-left py-2 px-3 text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500 hover:text-white"
            >
              Frequently Asked Questions (FAQ)
            </button>
            <button
              onClick={() => handleLinkClick('about')}
              className="w-full text-left py-2 px-3 text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500 hover:text-white"
            >
              About VELOZA YT
            </button>
            <button
              onClick={() => handleLinkClick('contact')}
              className="w-full text-left py-2 px-3 text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500 hover:text-white"
            >
              Contact Support
            </button>
          </div>
        </div>
      )}
    </header>
  );
};
