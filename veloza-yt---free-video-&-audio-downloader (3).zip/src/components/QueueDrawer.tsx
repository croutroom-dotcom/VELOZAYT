import React from 'react';
import { DownloadJob } from '../types';
import { X, Download, Loader2, CheckCircle2, Clock, Trash2, AlertCircle } from 'lucide-react';

interface QueueDrawerProps {
  isOpen: boolean;
  onClose: () => void;
  jobs: DownloadJob[];
  onRemoveJob: (id: string) => void;
  onClearCompleted: () => void;
}

export const QueueDrawer: React.FC<QueueDrawerProps> = ({
  isOpen,
  onClose,
  jobs,
  onRemoveJob,
  onClearCompleted,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 overflow-hidden bg-black/60 backdrop-blur-sm flex justify-end">
      <div className="relative w-full max-w-md bg-[#0e1017] dark:bg-[#0e1017] bg-white h-full border-l border-neutral-800 dark:border-neutral-800 border-neutral-300 shadow-2xl flex flex-col">
        {/* Header */}
        <div className="px-5 py-4 border-b border-neutral-800 dark:border-neutral-800 border-neutral-200 flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white dark:text-white text-neutral-900">
              Download Queue ({jobs.length})
            </h3>
            <span className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500">
              Background job processing & rendering
            </span>
          </div>

          <div className="flex items-center gap-1">
            {jobs.some((j) => j.status === 'completed') && (
              <button
                onClick={onClearCompleted}
                className="p-1.5 text-xs text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
                title="Clear completed jobs"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
            <button
              onClick={onClose}
              className="p-1.5 text-neutral-400 hover:text-white rounded-lg transition-colors cursor-pointer"
              aria-label="Close queue"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Job List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {jobs.length === 0 ? (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-neutral-500">
              <Download className="w-10 h-10 mb-2 stroke-1 text-neutral-600" />
              <p className="text-sm font-medium text-neutral-400">Queue is currently empty</p>
              <p className="text-xs text-neutral-500 mt-1 max-w-xs">
                When you click "Queue Job", files will process here with live progress, speed tracking, and cryptographic token isolation.
              </p>
            </div>
          ) : (
            jobs.map((job) => {
              const isCompleted = job.status === 'completed';
              const isProcessing = job.status === 'processing' || job.status === 'pending';
              const isFailed = job.status === 'failed';

              return (
                <div
                  key={job.id}
                  className="p-3.5 rounded-xl bg-neutral-900/80 dark:bg-neutral-900/80 bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-200 transition-all"
                >
                  <div className="flex items-start justify-between gap-2 mb-2">
                    <div className="flex-1 min-w-0">
                      <h4 className="text-xs font-bold text-white dark:text-white text-neutral-900 truncate">
                        {job.title}
                      </h4>
                      <div className="flex items-center gap-2 text-[11px] text-neutral-400 mt-0.5">
                        <span className="font-semibold text-[#7C5CFF]">{job.quality}</span>
                        <span>·</span>
                        <span>{job.fileSize}</span>
                        {job.verifiedIntegrity && (
                          <>
                            <span>·</span>
                            <span className="text-emerald-400 text-[10px]">Verified</span>
                          </>
                        )}
                      </div>
                    </div>

                    <button
                      onClick={() => onRemoveJob(job.id)}
                      className="text-neutral-500 hover:text-neutral-300 p-1 cursor-pointer"
                      title="Remove from queue"
                    >
                      <X className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  {/* Progress bar */}
                  <div className="w-full bg-neutral-800 dark:bg-neutral-800 bg-neutral-300 h-2 rounded-full overflow-hidden mb-2">
                    <div
                      className={`h-full transition-all duration-300 rounded-full ${
                        isCompleted
                          ? 'bg-emerald-500'
                          : isFailed
                          ? 'bg-red-500'
                          : 'bg-gradient-to-r from-[#7C5CFF] to-[#9b82ff]'
                      }`}
                      style={{ width: `${job.progress}%` }}
                    />
                  </div>

                  {/* Progress Meta */}
                  <div className="flex items-center justify-between text-[11px]">
                    <div className="flex items-center gap-1.5 text-neutral-400">
                      {isProcessing && <Loader2 className="w-3 h-3 animate-spin text-[#7C5CFF]" />}
                      {isCompleted && <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />}
                      {isFailed && <AlertCircle className="w-3.5 h-3.5 text-red-400" />}
                      <span className="capitalize">{job.status}</span>
                      {isProcessing && <span>({job.progress}%)</span>}
                    </div>

                    <div className="text-right text-neutral-400 font-mono">
                      {isProcessing && (
                        <span>
                          {job.speed} · ETA {job.eta}
                        </span>
                      )}
                      {isCompleted && <span className="text-emerald-400 font-semibold">100% Ready</span>}
                      {isFailed && <span className="text-red-400 font-semibold">{job.errorReason || 'Failed'}</span>}
                    </div>
                  </div>

                  {/* Download Action when completed */}
                  {isCompleted && job.downloadUrl && (
                    <a
                      href={job.downloadUrl}
                      download
                      className="mt-3 w-full py-2 px-3 bg-emerald-600 hover:bg-emerald-500 text-white font-bold rounded-lg text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                    >
                      <Download className="w-3.5 h-3.5" />
                      Save File to Device
                    </a>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
