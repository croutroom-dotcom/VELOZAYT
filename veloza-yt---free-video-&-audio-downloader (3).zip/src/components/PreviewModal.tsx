import React, { useRef } from 'react';
import { MediaMetadata } from '../types';
import { X, Play, Volume2, Film } from 'lucide-react';

interface PreviewModalProps {
  media: MediaMetadata | null;
  onClose: () => void;
}

export const PreviewModal: React.FC<PreviewModalProps> = ({ media, onClose }) => {
  if (!media) return null;

  // Stream preview URL
  const isDirectVideo = media.url.match(/\.(mp4|webm|mov|mp3|m4a|ogg)$/i) || media.url.includes('mozilla.net') || media.url.includes('w3schools.com');
  const previewSrc = isDirectVideo
    ? media.url
    : 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4';

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-fade-in">
      <div className="relative w-full max-w-3xl bg-[#0e1017] border border-neutral-800 rounded-2xl overflow-hidden shadow-2xl">
        {/* Header */}
        <div className="px-5 py-3.5 border-b border-neutral-800 flex items-center justify-between bg-neutral-900/60">
          <div className="flex items-center gap-2">
            <Film className="w-4 h-4 text-[#E51B2B]" />
            <span className="text-sm font-bold text-white truncate max-w-md">
              {media.title}
            </span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-white rounded-lg hover:bg-neutral-800 transition-colors cursor-pointer"
            aria-label="Close preview"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Video Player */}
        <div className="relative aspect-video bg-black flex items-center justify-center">
          <video
            src={previewSrc}
            controls
            autoPlay
            playsInline
            className="w-full h-full object-contain"
          />
        </div>

        {/* Footer Info */}
        <div className="p-4 bg-[#08090D] flex flex-wrap items-center justify-between gap-3 text-xs text-neutral-400">
          <div>
            <span className="text-white font-medium">Source: {media.platform}</span> · Duration: {media.duration}
          </div>
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400" />
            <span>High-definition direct streaming preview</span>
          </div>
        </div>
      </div>
    </div>
  );
};
