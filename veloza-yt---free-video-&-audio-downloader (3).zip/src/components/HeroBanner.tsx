import React, { useState } from 'react';
import {
  Sparkles,
  ArrowRight,
  Clipboard,
  X,
  Loader2,
  Film,
  Music2,
  FolderArchive,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface HeroBannerProps {
  onAnalyzeUrl: (url: string) => void;
  isLoading: boolean;
  inputRef?: React.RefObject<HTMLInputElement | null>;
  onFocusInput?: () => void;
}

export const HeroBanner: React.FC<HeroBannerProps> = ({
  onAnalyzeUrl,
  isLoading,
  inputRef,
  onFocusInput,
}) => {
  const [url, setUrl] = useState('');
  const [inputError, setInputError] = useState<string | null>(null);

  const sampleLinks = [
    { label: '4K Ultra HD', url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-videos/flower.mp4' },
    { label: '1080p Animation', url: 'https://www.w3schools.com/html/mov_bbb.mp4' },
    { label: '320k Audio Master', url: 'https://interactive-examples.mdn.mozilla.net/media/cc0-audio/t-rex-roar.mp3' },
  ];

  const handlePaste = async () => {
    try {
      const text = await navigator.clipboard.readText();
      if (text) {
        setUrl(text);
        setInputError(null);
        onAnalyzeUrl(text);
      }
    } catch {
      setInputError('Clipboard permission denied. Please paste manually.');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!url.trim()) {
      setInputError('Please enter or paste a valid media URL.');
      return;
    }
    setInputError(null);
    onAnalyzeUrl(url.trim());
  };

  return (
    <section className="relative w-full overflow-hidden bg-[#08090D] border-b border-neutral-800/80">
      {/* Background Cinematic Atmosphere & Glowing Electric Purple Lights */}
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_90%_60%_at_50%_-10%,rgba(124,92,255,0.22),transparent_75%)] pointer-events-none" />
      <div className="absolute top-1/4 right-10 w-[500px] h-[500px] bg-[#7C5CFF]/15 blur-[120px] pointer-events-none rounded-full" />
      <div className="absolute bottom-10 left-10 w-96 h-96 bg-[#7C5CFF]/10 blur-[100px] pointer-events-none rounded-full" />

      {/* Subtle Grid Accent */}
      <div className="absolute inset-0 bg-[linear-gradient(to_right,rgba(255,255,255,0.02)_1px,transparent_1px),linear-gradient(to_bottom,rgba(255,255,255,0.02)_1px,transparent_1px)] bg-[size:4rem_4rem] [mask-image:radial-gradient(ellipse_60%_50%_at_50%_40%,#000_70%,transparent_100%)] pointer-events-none" />

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-10 pb-16 md:pt-16 md:pb-24 relative z-10">
        {/* Top Tagline & Trust Row */}
        <div className="flex flex-wrap items-center justify-between gap-4 pb-8 mb-10 border-b border-neutral-800/60">
          <div className="flex items-center gap-2.5 text-xs font-bold tracking-wider uppercase">
            <span className="px-2.5 py-0.5 rounded-full bg-[#7C5CFF]/20 text-[#7C5CFF] border border-[#7C5CFF]/30 font-black">
              VELOZA YT
            </span>
            <span className="text-neutral-600">·</span>
            <span className="text-[#D9DDE3]">Videos. Audio. Your Way.</span>
          </div>

          <div className="flex items-center gap-6 text-xs text-neutral-400 font-medium">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="w-4 h-4 text-emerald-400" />
              100% Free & Verified Playable
            </span>
            <span className="flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-[#7C5CFF]" />
              Zero Throttling
            </span>
            <span className="hidden sm:flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-purple-300" />
              No Account Required
            </span>
          </div>
        </div>

        {/* 2-Column Wide Hero Banner Split */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 lg:gap-12 items-center">
          {/* Left Column: Headlines, Description & Integrated Modern Input */}
          <div className="lg:col-span-7 space-y-6">
            {/* Format Pills */}
            <div className="flex flex-wrap items-center gap-2 text-[11px] font-bold tracking-wider uppercase text-neutral-300">
              <span className="px-2.5 py-1 rounded-md bg-[#7C5CFF] text-[#F5F5F7] shadow-sm shadow-[#7C5CFF]/40 font-extrabold">
                4K ULTRA HD
              </span>
              <span className="text-neutral-600">|</span>
              <span className="px-2 py-0.5 rounded-md bg-neutral-900/90 border border-neutral-700/80 text-[#D9DDE3]">
                1080p FULL HD
              </span>
              <span className="text-neutral-600">|</span>
              <span className="px-2 py-0.5 rounded-md bg-neutral-900/90 border border-neutral-700/80 text-[#D9DDE3]">
                320kbps MP3
              </span>
              <span className="text-neutral-600">|</span>
              <span className="px-2 py-0.5 rounded-md bg-neutral-900/90 border border-neutral-700/80 text-[#D9DDE3]">
                ZIP ARCHIVE
              </span>
            </div>

            {/* Large Headline */}
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-[#F5F5F7] leading-[1.06] text-balance">
              YOUR MEDIA.{' '}
              <span className="bg-gradient-to-r from-[#7C5CFF] via-purple-300 to-[#D9DDE3] bg-clip-text text-transparent">
                YOUR WAY.
              </span>
            </h1>

            {/* Supporting Text */}
            <p className="text-base sm:text-lg text-[#D9DDE3] max-w-xl leading-relaxed font-normal">
              Download and manage your media with a simple, seamless experience. High-speed video, studio audio, and batch packaging across YouTube, TikTok, Vimeo, and more.
            </p>

            {/* Modern URL Input Field with "Get Started" Purple Button */}
            <div className="pt-2">
              <form
                onSubmit={handleSubmit}
                className="relative rounded-2xl p-2 bg-[#11131A] border border-neutral-800 shadow-2xl focus-within:border-[#7C5CFF] focus-within:ring-2 focus-within:ring-[#7C5CFF]/30 transition-all glow-subtle"
              >
                <div className="flex flex-col sm:flex-row items-center gap-2">
                  <div className="relative flex-1 w-full">
                    <input
                      ref={inputRef}
                      type="text"
                      value={url}
                      onChange={(e) => {
                        setUrl(e.target.value);
                        if (inputError) setInputError(null);
                      }}
                      placeholder="Paste your media URL here..."
                      className="w-full pl-4 pr-20 py-3.5 bg-transparent text-[#F5F5F7] placeholder:text-neutral-500 text-sm sm:text-base outline-none"
                      aria-label="Media URL input"
                    />

                    {/* Clear or Paste inside input */}
                    <div className="absolute inset-y-0 right-2 flex items-center gap-1.5">
                      {url ? (
                        <button
                          type="button"
                          onClick={() => setUrl('')}
                          className="p-1.5 text-neutral-400 hover:text-white rounded-md transition-colors cursor-pointer"
                          title="Clear input"
                        >
                          <X className="w-4 h-4" />
                        </button>
                      ) : (
                        <button
                          type="button"
                          onClick={handlePaste}
                          className="px-2.5 py-1.5 text-xs font-semibold text-neutral-300 hover:text-white bg-neutral-800/90 rounded-lg hover:bg-neutral-700 transition-colors flex items-center gap-1 cursor-pointer"
                          title="Paste from clipboard"
                        >
                          <Clipboard className="w-3.5 h-3.5" />
                          <span className="hidden xs:inline">Paste</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Premium Purple "Get Started" Button */}
                  <button
                    type="submit"
                    disabled={isLoading}
                    className="w-full sm:w-auto px-7 py-3.5 bg-[#7C5CFF] hover:bg-[#6c48ff] text-[#F5F5F7] font-bold rounded-xl shadow-lg shadow-[#7C5CFF]/40 hover:shadow-[#7C5CFF]/60 transition-all flex items-center justify-center gap-2 cursor-pointer disabled:opacity-60 whitespace-nowrap active:scale-95"
                  >
                    {isLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 animate-spin" />
                        Analyzing...
                      </>
                    ) : (
                      <>
                        <span>Get Started</span>
                        <ArrowRight className="w-4 h-4" />
                      </>
                    )}
                  </button>
                </div>

                {inputError && (
                  <div className="px-3 pt-2 pb-1 text-xs text-red-400 font-medium">
                    {inputError}
                  </div>
                )}
              </form>

              {/* Quick Sample Links Strip */}
              <div className="mt-3 flex flex-wrap items-center gap-2 text-xs text-neutral-400">
                <span className="font-semibold text-neutral-300">Quick Test:</span>
                {sampleLinks.map((s, idx) => (
                  <button
                    key={idx}
                    type="button"
                    onClick={() => {
                      setUrl(s.url);
                      setInputError(null);
                      onAnalyzeUrl(s.url);
                    }}
                    className="px-2.5 py-1 rounded-lg bg-neutral-900 border border-neutral-800 text-neutral-300 hover:text-white hover:border-[#7C5CFF]/60 transition-colors cursor-pointer text-[11px]"
                  >
                    {s.label}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Right Column: Sophisticated 3D Visual with Video, Audio, MP4, MP3 & ZIP */}
          <div className="lg:col-span-5 relative flex items-center justify-center">
            {/* Luminous Glow Behind 3D Visual */}
            <div className="absolute inset-0 bg-[#7C5CFF]/20 blur-3xl rounded-3xl pointer-events-none" />

            {/* Glassmorphic Frame Container */}
            <div className="relative w-full rounded-3xl overflow-hidden border border-neutral-700/80 bg-gradient-to-b from-neutral-900/90 to-[#08090D]/90 shadow-2xl glow-purple backdrop-blur-xl group transition-all duration-300 hover:border-[#7C5CFF]/60">
              {/* Generated 3D Asset */}
              <div className="relative aspect-[16/10] sm:aspect-video w-full overflow-hidden">
                <img
                  src="/src/assets/images/veloza_purple_hero_1793361197618.jpg"
                  alt="VELOZA YT 3D Media Visualizer with Video Player, MP4, MP3, Audio Waveform and ZIP Archive"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover object-center transform group-hover:scale-102 transition-transform duration-500"
                />

                {/* Glass Scrim Overlay */}
                <div className="absolute inset-0 bg-gradient-to-t from-[#08090D] via-transparent to-transparent opacity-60" />
                <div className="absolute inset-0 bg-gradient-to-tr from-[#7C5CFF]/15 via-transparent to-transparent pointer-events-none" />
              </div>

              {/* Floating Media Spec Badges */}
              <div className="p-4 sm:p-5 border-t border-neutral-800/80 bg-[#11131A]/80 backdrop-blur-md flex items-center justify-between text-xs">
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-lg bg-[#7C5CFF]/20 border border-[#7C5CFF]/40 flex items-center justify-center text-[#7C5CFF]">
                    <Film className="w-4 h-4" />
                  </div>
                  <div>
                    <span className="font-bold text-[#F5F5F7] block">Unified Media Suite</span>
                    <span className="text-[11px] text-neutral-400">MP4 · MP3 320k · ZIP Batch</span>
                  </div>
                </div>

                <div className="flex items-center gap-1.5 text-[11px] text-emerald-400 font-semibold px-2 py-1 rounded-md bg-emerald-500/10 border border-emerald-500/20">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse" />
                  <span>FFmpeg v7.1 Ready</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
