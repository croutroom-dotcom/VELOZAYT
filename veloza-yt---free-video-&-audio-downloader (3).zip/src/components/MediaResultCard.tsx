import React, { useState } from 'react';
import { MediaMetadata, FormatOption } from '../types';
import {
  Download,
  Play,
  Clock,
  Film,
  Music2,
  Check,
  ShieldAlert,
  Share2,
  ListPlus,
  ShieldCheck,
  AlertTriangle,
} from 'lucide-react';

interface MediaResultCardProps {
  media: MediaMetadata;
  onStartDirectDownload: (format: FormatOption) => void;
  onAddToQueue: (format: FormatOption) => void;
  onOpenPreview: (media: MediaMetadata) => void;
  onCopyLink: (url: string) => void;
}

export const MediaResultCard: React.FC<MediaResultCardProps> = ({
  media,
  onStartDirectDownload,
  onAddToQueue,
  onOpenPreview,
  onCopyLink,
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'audio'>('video');
  const [selectedFormatId, setSelectedFormatId] = useState<string>(
    media.formats.find((f) => f.type === 'video' && f.isRecommended)?.id ||
      media.formats.find((f) => f.type === 'video')?.id ||
      media.formats[0]?.id
  );

  const videoFormats = media.formats.filter((f) => f.type === 'video');
  const audioFormats = media.formats.filter((f) => f.type === 'audio');
  const currentList = activeTab === 'video' ? videoFormats : audioFormats;

  const currentSelectedFormat = media.formats.find((f) => f.id === selectedFormatId) || media.formats[0];

  const handleTabChange = (tab: 'video' | 'audio') => {
    setActiveTab(tab);
    const firstOfTab = media.formats.find((f) => f.type === tab);
    if (firstOfTab) {
      setSelectedFormatId(firstOfTab.id);
    }
  };

  return (
    <div className="w-full max-w-4xl mx-auto mt-8 px-4">
      <div className="bg-[#11131A] dark:bg-[#11131A] bg-white rounded-2xl border border-neutral-800 dark:border-neutral-800 border-neutral-300 shadow-2xl overflow-hidden transition-all">
        {/* Top Header Strip with Platform & Integrity Status */}
        <div className="px-6 py-4 border-b border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200 flex flex-wrap items-center justify-between gap-3 bg-neutral-900/40 dark:bg-neutral-900/40 bg-neutral-50">
          <div className="flex items-center gap-2.5">
            <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-[#7C5CFF]/20 text-[#7C5CFF] border border-[#7C5CFF]/30">
              {media.platform}
            </span>
            {media.verifiedIntegrity ? (
              <span className="px-2 py-0.5 text-[11px] font-semibold text-emerald-400 bg-emerald-500/10 border border-emerald-500/30 rounded-md flex items-center gap-1">
                <ShieldCheck className="w-3.5 h-3.5" />
                Stream Integrity Verified
              </span>
            ) : (
              <span className="text-xs text-neutral-400 dark:text-neutral-400 text-neutral-500">
                Public Media Stream
              </span>
            )}
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => onCopyLink(media.url)}
              className="px-3 py-1.5 text-xs text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:text-white dark:hover:text-white bg-neutral-800 dark:bg-neutral-800 bg-neutral-200 hover:bg-neutral-700 rounded-lg transition-colors flex items-center gap-1.5 cursor-pointer"
            >
              <Share2 className="w-3.5 h-3.5" />
              Copy URL
            </button>
          </div>
        </div>

        {/* Media Details Split */}
        <div className="p-6 grid grid-cols-1 md:grid-cols-12 gap-6">
          {/* Thumbnail & Quick Preview Area */}
          <div className="md:col-span-5 flex flex-col gap-3">
            <div className="relative rounded-xl overflow-hidden aspect-video bg-neutral-900 border border-neutral-800 group">
              <img
                src={media.thumbnail}
                alt={media.title}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                onError={(e) => {
                  (e.target as HTMLImageElement).src =
                    '/src/assets/images/veloza_purple_hero_1793361197618.jpg';
                }}
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-transparent to-transparent opacity-80" />

              {/* Play Overlay Button */}
              <button
                onClick={() => onOpenPreview(media)}
                className="absolute inset-0 m-auto w-12 h-12 rounded-full bg-[#7C5CFF] text-white flex items-center justify-center shadow-lg shadow-[#7C5CFF]/50 hover:scale-110 active:scale-95 transition-all cursor-pointer"
                title="Preview Media"
                aria-label="Preview Media"
              >
                <Play className="w-5 h-5 ml-0.5 fill-current" />
              </button>

              {/* Duration badge */}
              <div className="absolute bottom-2.5 right-2.5 px-2 py-0.5 rounded bg-black/85 text-white text-[11px] font-mono flex items-center gap-1">
                <Clock className="w-3 h-3" />
                {media.duration}
              </div>
            </div>

            {/* Quick Preview Hint */}
            <button
              onClick={() => onOpenPreview(media)}
              className="w-full py-2 px-3 text-xs font-semibold text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:text-white dark:hover:text-white bg-neutral-800/80 dark:bg-neutral-800/80 bg-neutral-100 hover:bg-neutral-700 dark:hover:bg-neutral-700 rounded-lg transition-colors flex items-center justify-center gap-2 cursor-pointer"
            >
              <Play className="w-3.5 h-3.5" />
              Open In-Browser Player Preview
            </button>
          </div>

          {/* Media Info & Format Picker */}
          <div className="md:col-span-7 flex flex-col justify-between">
            <div>
              <h2 className="text-lg sm:text-xl font-bold text-white dark:text-white text-neutral-900 leading-snug line-clamp-2 mb-1.5">
                {media.title}
              </h2>
              <div className="flex items-center gap-2 text-xs text-neutral-400 mb-4">
                <span>By {media.author}</span>
                <span>·</span>
                <span>Aspect: {media.aspectRatio}</span>
                <span>·</span>
                <span className="font-mono">{media.duration}</span>
              </div>

              {media.notice && (
                <div className="mb-4 p-2.5 rounded-lg bg-amber-950/30 border border-amber-800/40 text-amber-300 text-xs flex items-center gap-2">
                  <ShieldAlert className="w-4 h-4 shrink-0 text-amber-400" />
                  <span>{media.notice}</span>
                </div>
              )}

              {/* Media Format Category Tabs */}
              <div className="flex items-center gap-2 p-1 rounded-xl bg-neutral-900 dark:bg-neutral-900 bg-neutral-100 border border-neutral-800 dark:border-neutral-800 border-neutral-200 mb-4">
                <button
                  type="button"
                  onClick={() => handleTabChange('video')}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    activeTab === 'video'
                      ? 'bg-[#7C5CFF] text-[#F5F5F7] shadow-md shadow-[#7C5CFF]/30'
                      : 'text-neutral-400 dark:text-neutral-400 text-neutral-600 hover:text-white dark:hover:text-white'
                  }`}
                >
                  <Film className="w-4 h-4" />
                  Video Formats ({videoFormats.length})
                </button>
                <button
                  type="button"
                  onClick={() => handleTabChange('audio')}
                  className={`flex-1 py-2 px-3 rounded-lg text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    activeTab === 'audio'
                      ? 'bg-[#7C5CFF] text-[#F5F5F7] shadow-md shadow-[#7C5CFF]/30'
                      : 'text-neutral-400 dark:text-neutral-400 text-neutral-600 hover:text-white dark:hover:text-white'
                  }`}
                >
                  <Music2 className="w-4 h-4" />
                  Audio Extractions ({audioFormats.length})
                </button>
              </div>

              {/* Format Options List */}
              <div className="space-y-2 max-h-56 overflow-y-auto pr-1">
                {currentList.map((fmt) => {
                  const isSelected = selectedFormatId === fmt.id;
                  return (
                    <button
                      key={fmt.id}
                      type="button"
                      onClick={() => setSelectedFormatId(fmt.id)}
                      className={`w-full text-left p-3 rounded-xl border transition-all flex items-center justify-between cursor-pointer ${
                        isSelected
                          ? 'bg-[#7C5CFF]/10 border-[#7C5CFF] text-white'
                          : 'bg-neutral-900/60 dark:bg-neutral-900/60 bg-neutral-50 border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200 text-neutral-300 dark:text-neutral-300 text-neutral-700 hover:border-neutral-600'
                      }`}
                    >
                      <div className="flex items-center gap-3">
                        <div
                          className={`w-5 h-5 rounded-full border flex items-center justify-center transition-colors ${
                            isSelected
                              ? 'border-[#7C5CFF] bg-[#7C5CFF] text-white'
                              : 'border-neutral-600'
                          }`}
                        >
                          {isSelected && <Check className="w-3 h-3 stroke-[3]" />}
                        </div>

                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-bold text-xs sm:text-sm text-white dark:text-white text-neutral-900">
                              {fmt.quality}
                            </span>
                            {fmt.isUltraHd && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-[#7C5CFF] text-white font-black uppercase">
                                4K
                              </span>
                            )}
                            {fmt.isRecommended && (
                              <span className="text-[10px] px-1.5 py-0.2 rounded bg-amber-500/20 text-amber-400 font-semibold">
                                Best
                              </span>
                            )}
                          </div>
                          <span className="text-[11px] text-neutral-400 dark:text-neutral-400 text-neutral-500">
                            {fmt.resolution} · {fmt.bitrate} · {fmt.format}
                          </span>
                        </div>
                      </div>

                      <div className="text-right">
                        <span className="text-xs font-mono font-semibold text-neutral-200 dark:text-neutral-200 text-neutral-800 block">
                          ~{fmt.fileSize}
                        </span>
                        <span className="text-[10px] text-emerald-400 font-medium">Verified Valid</span>
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Bottom Actions */}
            <div className="mt-6 pt-4 border-t border-neutral-800/80 dark:border-neutral-800/80 border-neutral-200 flex flex-col sm:flex-row items-center gap-3">
              <button
                type="button"
                onClick={() => onStartDirectDownload(currentSelectedFormat)}
                className="w-full sm:flex-1 py-3 px-5 bg-[#7C5CFF] hover:bg-[#6c48ff] text-[#F5F5F7] font-bold rounded-xl shadow-lg shadow-[#7C5CFF]/30 hover:shadow-[#7C5CFF]/50 transition-all flex items-center justify-center gap-2 cursor-pointer active:scale-95 text-sm"
              >
                <Download className="w-4 h-4" />
                Download {currentSelectedFormat.quality} ({currentSelectedFormat.fileSize})
              </button>

              <button
                type="button"
                onClick={() => onAddToQueue(currentSelectedFormat)}
                className="w-full sm:w-auto py-3 px-4 bg-neutral-800 hover:bg-neutral-700 dark:bg-neutral-800 dark:hover:bg-neutral-700 bg-neutral-200 hover:bg-neutral-300 text-neutral-200 dark:text-neutral-200 text-neutral-800 font-semibold rounded-xl transition-all flex items-center justify-center gap-1.5 cursor-pointer text-sm"
                title="Process in background queue"
              >
                <ListPlus className="w-4 h-4" />
                Queue Job
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
