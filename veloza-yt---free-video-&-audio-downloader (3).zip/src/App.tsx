import React, { useState, useEffect, useRef } from 'react';
import { PageView, MediaMetadata, FormatOption, DownloadJob, HistoryItem } from './types';
import { Header } from './components/Header';
import { HeroBanner } from './components/HeroBanner';
import { DownloaderEngine } from './components/DownloaderEngine';
import { MediaResultCard } from './components/MediaResultCard';
import { HomeFeatures } from './components/HomeFeatures';
import { HistorySection } from './components/HistorySection';
import { Footer } from './components/Footer';
import { QueueDrawer } from './components/QueueDrawer';
import { PreviewModal } from './components/PreviewModal';

// Pages
import { AboutPage } from './components/pages/AboutPage';
import { FeaturesPage } from './components/pages/FeaturesPage';
import { PlatformsPage } from './components/pages/PlatformsPage';
import { FaqPage } from './components/pages/FaqPage';
import { ContactPage } from './components/pages/ContactPage';
import { PrivacyPage } from './components/pages/PrivacyPage';
import { TermsPage } from './components/pages/TermsPage';
import { CopyrightPage } from './components/pages/CopyrightPage';
import { GuidePage } from './components/pages/GuidePage';
import { DiagnosticsPage } from './components/pages/DiagnosticsPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<PageView>('home');
  const [darkMode, setDarkMode] = useState<boolean>(() => {
    const saved = localStorage.getItem('veloza_theme');
    return saved ? saved === 'dark' : true;
  });

  const [analyzedMedia, setAnalyzedMedia] = useState<MediaMetadata | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [queueJobs, setQueueJobs] = useState<DownloadJob[]>([]);
  const [isQueueOpen, setIsQueueOpen] = useState<boolean>(false);
  const [previewMedia, setPreviewMedia] = useState<MediaMetadata | null>(null);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try {
      const saved = localStorage.getItem('veloza_history');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const inputRef = useRef<HTMLInputElement>(null);
  const resultCardRef = useRef<HTMLDivElement>(null);

  // Sync dark class with document.documentElement
  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('veloza_theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('veloza_theme', 'light');
    }
  }, [darkMode]);

  // Persist history to localStorage
  useEffect(() => {
    try {
      localStorage.setItem('veloza_history', JSON.stringify(history));
    } catch (e) {
      console.warn('LocalStorage error saving history:', e);
    }
  }, [history]);

  // Toast auto-clear
  useEffect(() => {
    if (toastMessage) {
      const timer = setTimeout(() => setToastMessage(null), 3500);
      return () => clearTimeout(timer);
    }
  }, [toastMessage]);

  // Polling for active background jobs
  useEffect(() => {
    const active = queueJobs.some((j) => j.status === 'pending' || j.status === 'processing');
    if (!active) return;

    const interval = setInterval(async () => {
      const updated = await Promise.all(
        queueJobs.map(async (job) => {
          if (job.status === 'completed' || job.status === 'failed') return job;
          try {
            const res = await fetch(`/api/job/status/${job.id}`);
            if (res.ok) {
              const data = await res.json();
              if (data && data.job) return data.job;
            }
          } catch {
            // Keep existing on transient failure
          }
          return job;
        })
      );
      setQueueJobs(updated);
    }, 600);

    return () => clearInterval(interval);
  }, [queueJobs]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
  };

  const handleMediaAnalyzed = (data: MediaMetadata) => {
    setAnalyzedMedia(data);
    setTimeout(() => {
      resultCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
    }, 100);
  };

  const handleAnalyzeUrl = async (rawUrl: string) => {
    if (!rawUrl || !rawUrl.trim()) {
      showToast('Please enter a valid video or audio URL.');
      return;
    }
    setIsLoading(true);
    try {
      const response = await fetch('/api/analyze', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ url: rawUrl.trim() }),
      });
      const resData = await response.json();
      if (!response.ok || !resData.success) {
        throw new Error(resData.error || 'Failed to analyze media link.');
      }
      setAnalyzedMedia(resData.data);
      showToast(`Stream Ready: "${resData.data.title}"`);
      setTimeout(() => {
        resultCardRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }, 150);
    } catch (err: any) {
      showToast(err.message || 'Error connecting to media server.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleFocusInput = () => {
    if (currentPage !== 'home') {
      setCurrentPage('home');
    }
    setTimeout(() => {
      inputRef.current?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      inputRef.current?.focus();
    }, 150);
  };

  const addToHistory = (title: string, url: string, fmt: FormatOption, thumbnail: string) => {
    const newItem: HistoryItem = {
      id: 'h_' + Date.now() + Math.random().toString(36).substring(2, 6),
      title,
      url,
      format: fmt.format,
      quality: fmt.quality,
      mediaType: fmt.type,
      fileSize: fmt.fileSize,
      timestamp: Date.now(),
      thumbnail,
    };
    setHistory((prev) => [newItem, ...prev.slice(0, 19)]);
  };

  const handleStartDirectDownload = (format: FormatOption) => {
    if (!analyzedMedia) return;

    const isAudio = format.type === 'audio' || format.id.startsWith('a_');
    const isM4a = format.format.toLowerCase().includes('m4a');
    const ext = isAudio ? (isM4a ? 'm4a' : 'mp3') : 'mp4';
    const safeTitle = (analyzedMedia.title || 'veloza_media')
      .replace(/[^a-zA-Z0-9_\-\. ]/g, '')
      .trim()
      .replace(/\s+/g, '_');
    const filename = `${safeTitle}_[VELOZA_YT].${ext}`;

    // Trigger verified streaming download via API
    const downloadUrl = `/api/download?url=${encodeURIComponent(analyzedMedia.url)}&formatId=${
      format.id
    }&mediaType=${format.type}&title=${encodeURIComponent(analyzedMedia.title)}`;

    const link = document.createElement('a');
    link.href = downloadUrl;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    addToHistory(analyzedMedia.title, analyzedMedia.url, format, analyzedMedia.thumbnail);
    showToast(`Downloading: ${format.quality} (${format.fileSize})`);
  };

  const handleAddToQueue = async (format: FormatOption) => {
    if (!analyzedMedia) return;

    try {
      const res = await fetch('/api/job/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          url: analyzedMedia.url,
          formatId: format.id,
          quality: format.quality,
          mediaType: format.type,
          title: analyzedMedia.title,
          fileSize: format.fileSize,
        }),
      });

      const data = await res.json();
      if (!res.ok || !data.success) {
        throw new Error(data.error || 'Failed to start background job.');
      }

      setQueueJobs((prev) => [data.job, ...prev]);
      setIsQueueOpen(true);
      addToHistory(analyzedMedia.title, analyzedMedia.url, format, analyzedMedia.thumbnail);
      showToast(`Added to queue: ${analyzedMedia.title}`);
    } catch (err: any) {
      showToast(`Queue failed: ${err.message}`);
    }
  };

  const handleDownloadAgain = (item: HistoryItem) => {
    const isAudio = item.mediaType === 'audio' || item.format.toLowerCase().includes('mp3') || item.format.toLowerCase().includes('m4a');
    const isM4a = item.format.toLowerCase().includes('m4a');
    const ext = isAudio ? (isM4a ? 'm4a' : 'mp3') : 'mp4';
    const safeTitle = (item.title || 'veloza_media')
      .replace(/[^a-zA-Z0-9_\-\. ]/g, '')
      .trim()
      .replace(/\s+/g, '_');
    const filename = `${safeTitle}_[VELOZA_YT].${ext}`;

    const downloadUrl = `/api/download?url=${encodeURIComponent(item.url)}&mediaType=${
      item.mediaType
    }&title=${encodeURIComponent(item.title)}`;
    const link = document.createElement('a');
    link.href = downloadUrl;
    link.setAttribute('download', filename);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast(`Re-downloading: ${item.title}`);
  };

  const handleCopyLink = async (targetUrl: string) => {
    try {
      await navigator.clipboard.writeText(targetUrl);
      showToast('Media URL copied to clipboard.');
    } catch {
      showToast('Failed to copy link.');
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    localStorage.removeItem('veloza_history');
    showToast('Download history cleared.');
  };

  const handleRemoveQueueJob = (id: string) => {
    setQueueJobs((prev) => prev.filter((j) => j.id !== id));
  };

  const handleClearCompletedJobs = () => {
    setQueueJobs((prev) => prev.filter((j) => j.status !== 'completed'));
    showToast('Completed queue jobs cleared.');
  };

  return (
    <div className="min-h-screen flex flex-col bg-[#08090D] dark:bg-[#08090D] bg-neutral-50 text-white dark:text-white text-neutral-900 transition-colors">
      {/* Top Navigation */}
      <Header
        currentPage={currentPage}
        onNavigate={setCurrentPage}
        darkMode={darkMode}
        onToggleTheme={() => setDarkMode(!darkMode)}
        activeJobsCount={queueJobs.filter((j) => j.status === 'processing' || j.status === 'pending').length}
        onOpenQueue={() => setIsQueueOpen(true)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentPage === 'home' && (
          <>
            {/* Hero Banner Visual Showcase & Instant URL Downloader */}
            <HeroBanner
              onAnalyzeUrl={handleAnalyzeUrl}
              isLoading={isLoading}
              inputRef={inputRef}
              onFocusInput={handleFocusInput}
            />

            {/* Downloader Engine Input Box & Advanced Tools */}
            <DownloaderEngine
              onMediaAnalyzed={handleMediaAnalyzed}
              isLoading={isLoading}
              setIsLoading={setIsLoading}
              inputRef={inputRef}
            />

            {/* Analyzed Media Card */}
            {analyzedMedia && (
              <div ref={resultCardRef}>
                <MediaResultCard
                  media={analyzedMedia}
                  onStartDirectDownload={handleStartDirectDownload}
                  onAddToQueue={handleAddToQueue}
                  onOpenPreview={setPreviewMedia}
                  onCopyLink={handleCopyLink}
                />
              </div>
            )}

            {/* Recent Downloads History */}
            <HistorySection
              history={history}
              onClearHistory={handleClearHistory}
              onDownloadAgain={handleDownloadAgain}
              onCopyLink={handleCopyLink}
            />

            {/* Features, Workflow & Quality Matrix */}
            <HomeFeatures onNavigate={setCurrentPage} onFocusInput={handleFocusInput} />
          </>
        )}

        {currentPage === 'about' && <AboutPage />}
        {currentPage === 'features' && <FeaturesPage />}
        {currentPage === 'platforms' && <PlatformsPage />}
        {currentPage === 'faq' && <FaqPage />}
        {currentPage === 'contact' && <ContactPage />}
        {currentPage === 'privacy' && <PrivacyPage />}
        {currentPage === 'terms' && <TermsPage />}
        {currentPage === 'copyright' && <CopyrightPage />}
        {currentPage === 'guide' && <GuidePage />}
        {currentPage === 'diagnostics' && <DiagnosticsPage />}
      </main>

      {/* Footer */}
      <Footer onNavigate={setCurrentPage} />

      {/* Background Queue Drawer */}
      <QueueDrawer
        isOpen={isQueueOpen}
        onClose={() => setIsQueueOpen(false)}
        jobs={queueJobs}
        onRemoveJob={handleRemoveQueueJob}
        onClearCompleted={handleClearCompletedJobs}
      />

      {/* In-Browser Preview Modal */}
      <PreviewModal media={previewMedia} onClose={() => setPreviewMedia(null)} />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 px-4 py-3 rounded-xl bg-[#11131A] dark:bg-[#11131A] bg-neutral-900 text-white text-xs font-semibold shadow-2xl border border-neutral-700 flex items-center gap-2 animate-bounce-subtle">
          <span className="w-2 h-2 rounded-full bg-[#7C5CFF]" />
          <span>{toastMessage}</span>
        </div>
      )}
    </div>
  );
}
