export type PageView =
  | 'home'
  | 'about'
  | 'features'
  | 'platforms'
  | 'faq'
  | 'contact'
  | 'privacy'
  | 'terms'
  | 'copyright'
  | 'guide'
  | 'diagnostics';

export interface FormatOption {
  id: string;
  type: 'video' | 'audio';
  quality: string;
  resolution: string;
  fps?: number;
  format: string;
  bitrate: string;
  fileSize: string;
  fileSizeBytes?: number;
  isUltraHd?: boolean;
  isPopular?: boolean;
  isRecommended?: boolean;
  verified?: boolean;
}

export interface MediaMetadata {
  url: string;
  title: string;
  author: string;
  duration: string;
  durationSec: number;
  platform: string;
  platformStatus?: 'verified' | 'restricted' | 'drm_unsupported';
  aspectRatio: string;
  thumbnail: string;
  description?: string;
  notice?: string;
  formats: FormatOption[];
  verifiedIntegrity?: boolean;
  contentLengthBytes?: number;
}

export interface DownloadJob {
  id: string;
  token: string;
  url: string;
  title: string;
  formatId: string;
  quality: string;
  mediaType: 'video' | 'audio';
  progress: number;
  speed: string;
  eta: string;
  status: 'pending' | 'processing' | 'completed' | 'failed';
  downloadUrl?: string;
  fileSize: string;
  fileSizeBytes?: number;
  errorReason?: string;
  verifiedIntegrity: boolean;
  createdAt: number;
  completedAt?: number;
}

export interface HistoryItem {
  id: string;
  title: string;
  url: string;
  format: string;
  quality: string;
  mediaType: 'video' | 'audio';
  fileSize: string;
  timestamp: number;
  thumbnail: string;
}

export interface PlatformItem {
  id: string;
  name: string;
  category: 'supported' | 'restricted' | 'unsupported_drm';
  badge: string;
  status: 'Operational' | 'Requires Auth' | 'DRM Protected (Unavailable)';
  description: string;
  formats: string[];
  notes?: string;
  legalReason?: string;
  authorizedAlternative?: string;
}

export interface DiagnosticTestResult {
  id: string;
  name: string;
  category: 'Security' | 'Network' | 'Integrity' | 'Queue' | 'Storage';
  passed: boolean;
  durationMs: number;
  details: string;
}

export interface SystemHealth {
  status: 'healthy' | 'degraded';
  uptimeSeconds: number;
  memory: {
    rssMb: number;
    heapUsedMb: number;
    heapTotalMb: number;
  };
  activeJobsCount: number;
  tempStorageUsageMb: number;
  maxStorageLimitMb: number;
  rateLimitHits: number;
  timestamp: number;
}
